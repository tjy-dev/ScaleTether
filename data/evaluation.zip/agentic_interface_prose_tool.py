#!/usr/bin/env python3
"""Read-only benchmark tool exposing policy guidance as untyped prose."""

from __future__ import annotations

import argparse
import json

from agentic_interface_tool import CORPUS, measure, task


def prose_query(row: dict[str, object]) -> dict[str, object]:
    action = str(row["frozen_action"])
    reason = str(row["reason_code"])
    if action == "ESTIMATE":
        guidance = (
            f"The available evidence supports selecting TP {row['certified_tp']} "
            f"without additional measurement. Rationale: {reason}."
        )
    elif action == "MEASURE":
        runs = ", ".join(f"TP {tp}" for tp in row["required_measurements"])
        guidance = (
            f"The current evidence is insufficient for selection. Measure {runs}, "
            f"then select the fastest measured candidate. Rationale: {reason}."
        )
    else:
        guidance = (
            "This request is outside the validated domain. Stop without selecting "
            f"a TP degree or taking measurements. Rationale: {reason}."
        )
    return {
        "case_id": row["case_id"],
        "workload": {
            "hidden_size": row.get("hidden_size"),
            "sequence_length": row.get("sequence_length"),
            "condition": row.get("query"),
        },
        "candidate_tp": row["candidates"],
        "planning_guidance": guidance,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--case", required=True)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("query")
    measurement = subparsers.add_parser("measure")
    measurement.add_argument("--tp", type=int, required=True)
    args = parser.parse_args()
    row = task(args.case)
    result = prose_query(row) if args.command == "query" else measure(row, args.tp)
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()

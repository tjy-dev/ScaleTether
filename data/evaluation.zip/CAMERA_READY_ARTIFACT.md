# ScaleTether reproducibility archive

This archive extends the original reviewer snapshot with the matched-evidence
interface study and a deterministic reference controller. The original
`ARTIFACT_README.md` documents the retained physical and structural evidence.

The follow-up uses the same 15 offline cases, two models, two prompt lengths,
and two repetitions per interface: 240 sessions in total. Both interfaces
return the same support and calibration facts and the same model choices;
one adds an explicit action. Both prompts specify the same general policy.
The reference controller queries that evidence and the measurement tool.
No new GPU experiment or live scheduler deployment is represented.

With Python 3.10 or later, reconstruct scores from the retained transcripts:

```bash
python agentic_interface_matched_v4.py score --check
python -m unittest test_agentic_interface_matched_v4
python make_camera_ready_results.py
```

These commands need no network, GPU, model access, or third-party package.
The generated camera-ready tables can be compared byte-for-byte with the
archived tables. The freeze manifest records the protocol, input and program
hashes, CLI version, model identifiers, and deterministic session order.
Rendered prompts and every attempted session are retained. Timing and token
counts describe the recorded concurrent execution, not current model pricing.

The archive preserves original source hashes and hashes of distributed
members. Private filesystem roots and the local Python installation path are
replaced with portable tokens. Freeze hashes identify the original inputs;
redacted inputs intentionally have different byte hashes. The `score --check`
command reconstructs outcomes without requiring unredacted source identities.
Re-executing model sessions requires the original source layout, matching
frozen inputs, and model access; it is not part of CPU-only reproduction.

The structural evidence comprises compact validation records. Raw profiler
traces, private scheduler logs, and the complete captured/generated workload
corpus are not included. Physical capture and ASTRA-sim are not rerun by this
archive. The source-tree revision is recorded with its dirty-state flag and
per-member hashes rather than represented as a clean published commit.

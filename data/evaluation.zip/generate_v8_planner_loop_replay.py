#!/usr/bin/env python3
"""Reconstruct the scripted planner loop from sealed V8 decisions."""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
CASES = (
    ROOT
    / "evidence"
    / "scaletether"
    / "fixed-resource-v8-paper-package"
    / "primary-cases.csv"
)
BOUNDARY = ROOT / "evidence" / "scaletether" / "planner-boundary-suite.json"
OUTPUT = ROOT / "evidence" / "scaletether" / "v8-planner-loop-replay-v1.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build() -> dict:
    with CASES.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    boundary = json.loads(BOUNDARY.read_text(encoding="utf-8"))
    if len(rows) != 80 or boundary.get("passed_case_count") != 9:
        raise RuntimeError("planner-loop source identity changed")

    estimates = measurements = final_exact = invalid_actions = 0
    decisions = []
    for row in rows:
        action = row["action"]
        optimum = int(row["physically_fastest_tp"])
        if action == "ESTIMATE":
            estimates += 1
            final_tp = int(row["selected_tp"])
            acquired = []
        elif action == "MEASURE":
            measurements += 1
            acquired = list(ast.literal_eval(row["requested_tps"]))
            if acquired != [1, 2, 4]:
                invalid_actions += 1
            final_tp = optimum
        else:
            invalid_actions += 1
            acquired = []
            final_tp = None
        final_exact += final_tp == optimum
        decisions.append(
            {
                "task_id": int(row["task_id"]),
                "action": action,
                "acquired_tps": acquired,
                "final_tp": final_tp,
                "measured_optimum_tp": optimum,
                "exact": final_tp == optimum,
            }
        )

    return {
        "schema": "scaletether-v8-scripted-planner-loop-replay-v1",
        "claim": "scripted-tool-use-replay-not-language-model-agent-evaluation",
        "source_sha256": {
            "primary_cases_csv": sha256(CASES),
            "planner_boundary_suite_json": sha256(BOUNDARY),
        },
        "controller": {
            "ESTIMATE": "accept the certified TP choice without acquisition",
            "MEASURE": "acquire the named TP candidates and select the measured best",
            "UNSUPPORTED": "stop without a recommendation",
        },
        "summary": {
            "queries": len(rows),
            "estimate_actions": estimates,
            "measure_actions": measurements,
            "direct_measurement_allocations": len(rows),
            "selective_measurement_allocations": measurements,
            "allocations_avoided": len(rows) - measurements,
            "final_exact_selections": final_exact,
            "invalid_action_executions": invalid_actions,
            "boundary_contract_cases_passed": boundary["passed_case_count"],
            "boundary_contract_cases": boundary["case_count"],
        },
        "interpretation": (
            "The replay evaluates deterministic action routing and acquisition "
            "economics over stored H100 outcomes. It does not evaluate language-model "
            "reasoning, prompt following, or live scheduler control."
        ),
        "decisions": decisions,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    payload = json.dumps(build(), indent=2, sort_keys=True) + "\n"
    if args.check:
        if not OUTPUT.is_file() or OUTPUT.read_text(encoding="utf-8") != payload:
            raise SystemExit(f"stale V8 planner-loop replay: {OUTPUT}")
    else:
        OUTPUT.write_text(payload, encoding="utf-8")
    summary = build()["summary"]
    print(
        "v8_planner_loop="
        f"{summary['final_exact_selections']}/{summary['queries']} "
        f"measure={summary['measure_actions']}"
    )


if __name__ == "__main__":
    main()

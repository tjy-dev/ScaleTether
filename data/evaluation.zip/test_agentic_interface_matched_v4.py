"""Check experimental isolation, controller behavior, and strict scoring."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import agentic_interface_matched_v4 as study


class MatchedInterfaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.directory = Path(self.temp.name)
        frozen = self.directory / 'freeze.json'
        study.write(frozen, {'payloads': study.evidence_payloads()})
        self.override = patch.object(study, 'FREEZE', frozen)
        self.override.start()

    def tearDown(self):
        self.override.stop()
        self.temp.cleanup()

    def test_only_action_field_differs_and_outcomes_are_hidden(self):
        forbidden = {'measured_us', 'measured_optimum_tp', 'regret_percent',
                     'certified_tp', 'frozen_action', 'required_measurements'}
        for case_id in study.expected_tasks():
            evidence = study.query(case_id, 'evidence')
            action = study.query(case_id, 'action')
            self.assertEqual(set(action) - set(evidence), {'action'})
            self.assertEqual({k: v for k, v in action.items() if k != 'action'}, evidence)
            self.assertFalse(forbidden & set(evidence))
            self.assertEqual(action['action'], study.policy(evidence))

    def test_controller_uses_the_tool_and_matches_all_frozen_cases(self):
        for case_id, task in study.expected_tasks().items():
            with patch.object(study, 'measure', wraps=study.measure) as measurement:
                result = study.controller(case_id)
                score = study.outcome(task, result, result['measurements_used'])
                self.assertTrue(score['protocol_valid'], case_id)
                self.assertEqual(measurement.call_count, len(task['required_measurements']))

    def test_controller_selects_returned_measurements_not_saved_optimum(self):
        def different_times(case_id, tp):
            return {'tp': tp, 'median_iteration_us': {1: 30, 2: 10, 4: 20}[tp]}
        with patch.object(study, 'measure', side_effect=different_times):
            self.assertEqual(study.controller('v8-031')['selected_tp'], 2)

    def test_right_choice_without_required_measurements_fails(self):
        task = study.expected_tasks()['v8-031']
        result = {'decision': 'SELECT', 'selected_tp': 1, 'measurements_used': []}
        score = study.outcome(task, result, [])
        self.assertTrue(score['exact'])
        self.assertFalse(score['protocol_valid'])
        self.assertEqual(score['missing_measurements'], 3)

    def test_duplicate_or_misreported_measurements_fail(self):
        task = study.expected_tasks()['v8-031']
        result = {'decision': 'SELECT', 'selected_tp': 1, 'measurements_used': [1, 2, 4]}
        self.assertFalse(study.outcome(task, result, [1, 2, 4, 4])['protocol_valid'])
        result['measurements_used'] = [1]
        self.assertFalse(study.outcome(task, result, [1, 2, 4])['protocol_valid'])

    def test_unapproved_commands_and_extra_shell_commands_are_rejected(self):
        cell = {'interface': 'evidence', 'case_id': 'v8-031'}
        tool = '/usr/bin/python ' + str(Path(study.__file__))
        commands = [tool + ' query --interface evidence --case v8-031',
                    tool + ' measure --case v8-031 --tp 1',
                    tool + ' measure --case v8-031 --tp 2; cat /tmp/hidden',
                    'cat /tmp/hidden']
        path = self.directory / 'trace.jsonl'
        path.write_text('\n'.join(json.dumps({'type': 'item.completed', 'item': {
            'type': 'command_execution', 'command': c, 'exit_code': 0}}) for c in commands))
        calls, forbidden, _ = study.parsed_commands(path, cell)
        self.assertEqual(calls, [('query', None), ('measure', 1)])
        self.assertEqual(len(forbidden), 2)


if __name__ == '__main__':
    unittest.main()

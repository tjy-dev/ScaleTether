#!/usr/bin/env python3
"""Frozen, matched-evidence offline interface experiment and transcript scorer."""
from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import shlex
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE / 'evidence/scaletether'
ROOT = HERE.parents[1] if (HERE.parents[1] / 'docs/experiments').exists() else HERE
PROTOCOL = ROOT / 'docs/experiments/preregistered-agentic-interface-matched-v4.md'
CORPUS = EVIDENCE / 'agentic-interface-benchmark-v1.json'
CASES = EVIDENCE / 'fixed-resource-v8-paper-package/primary-cases.csv'
FREEZE = EVIDENCE / 'agentic-interface-matched-v4-freeze.json'
RESULT = EVIDENCE / 'agentic-interface-matched-v4-results.json'
RUNS = EVIDENCE / 'agentic-interface-matched-runs-v4'
SCHEMA = HERE / 'agentic_interface_response.schema.json'
PROMPTS = {label: HERE / name for label, name in {
    'standard': 'agentic_interface_matched_prompt.txt',
    'concise': 'agentic_interface_matched_prompt_concise.txt',
}.items()}
MODELS = {'sol': 'gpt-5.6-sol', 'terra': 'gpt-5.6-terra'}
INTERFACES = ('evidence', 'action')
EMPTY = Path('/tmp/scaletether-matched-v4-empty')


def load(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def timestamp():
    return datetime.now(timezone.utc).isoformat()


def expected_tasks():
    return {row['case_id']: row for row in load(CORPUS)['tasks']}


def policy(payload):
    if not all(payload['support_checks'].values()):
        return 'UNSUPPORTED'
    choices = list(payload['model_selected_tp'].values())
    if payload['calibration_status'] != 'stable' or not choices or len(set(choices)) != 1:
        return 'MEASURE'
    return 'ESTIMATE'


def evidence_payloads():
    with CASES.open() as handle:
        physical = {f"v8-{int(row['task_id']):03d}": row for row in csv.DictReader(handle)}
    boundary_fields = {
        'tp-transition-unsupported': 'tp_rule_supported',
        'framework-identity-mismatch': 'framework_matches',
        'pp-schedule-unsupported': 'pp_schedule_supported',
        'accelerator-identity-mismatch': 'hardware_matches',
        'runtime-identity-mismatch': 'software_matches',
    }
    payloads = {}
    for case_id, task in expected_tasks().items():
        checks = {key: True for key in boundary_fields.values()}
        row = physical.get(case_id)
        if row is None:
            checks[boundary_fields[task['reason_code']]] = False
        payload = {
            'case_id': case_id,
            'workload': {k: task.get(k) for k in ('hidden_size', 'sequence_length')},
            'candidate_tp': task['candidates'],
            'support_checks': checks,
            'calibration_status': 'stable' if row else 'not-applicable',
            'model_selected_tp': json.loads(row['method_selected_tps']) if row else {},
        }
        if policy(payload) != task['frozen_action']:
            raise ValueError(f'policy disagrees with frozen case {case_id}')
        payloads[case_id] = payload
    return payloads


def inputs():
    return [Path(__file__), PROTOCOL, CORPUS, CASES, SCHEMA, *PROMPTS.values()]


def freeze():
    if FREEZE.exists():
        raise ValueError('freeze already exists; immutable experimental record')
    payloads = evidence_payloads()
    matrix = [dict(model=m, prompt=p, repetition=r, interface=i, case_id=c)
              for m in MODELS for p in PROMPTS for r in (1, 2)
              for i in INTERFACES for c in payloads]
    random.Random(20260924).shuffle(matrix)
    write(FREEZE, {
        'schema': 'matched-evidence-v4-freeze', 'created_utc': timestamp(),
        'models': MODELS, 'reasoning_effort': 'medium',
        'codex_version': subprocess.check_output(['codex', '--version'], text=True).strip(),
        'inputs': {str(p.relative_to(ROOT)): digest(p) for p in inputs()},
        'payloads': payloads, 'matrix': matrix, 'timeout_seconds': 180,
        'workers': 4, 'seed': 20260924,
    })
    print(f'freeze={FREEZE} sessions={len(matrix)} sha256={digest(FREEZE)}')


def verified_freeze():
    frozen = load(FREEZE)
    for name, sha in frozen['inputs'].items():
        if digest(ROOT / name) != sha:
            raise ValueError(f'frozen input changed: {name}')
    if evidence_payloads() != frozen['payloads']:
        raise ValueError('evidence payloads changed')
    return frozen


def query(case_id, interface):
    payload = dict(load(FREEZE)['payloads'][case_id])
    if interface == 'action':
        payload['action'] = policy(payload)
    return payload


def measure(case_id, tp):
    row = expected_tasks()[case_id]
    if tp not in row['candidates']:
        raise ValueError('invalid candidate')
    if row['measured_us'] is None:
        return {'case_id': case_id, 'tp': tp, 'status': 'measurement-unavailable'}
    return {'case_id': case_id, 'tp': tp, 'status': 'measured',
            'median_iteration_us': row['measured_us'][str(tp)]}


def controller(case_id):
    payload = query(case_id, 'evidence')
    action = policy(payload)
    measurements = []
    if action == 'UNSUPPORTED':
        selected = None
    elif action == 'ESTIMATE':
        selected = next(iter(payload['model_selected_tp'].values()))
    else:
        measurements = [measure(case_id, tp) for tp in payload['candidate_tp']]
        selected = min(measurements, key=lambda row: row['median_iteration_us'])['tp']
    return {'decision': 'STOP' if selected is None else 'SELECT',
            'selected_tp': selected, 'measurements_used': [r['tp'] for r in measurements],
            'explanation': 'Applied the shared policy to the evidence interface.'}


def session_directory(cell):
    return RUNS / cell['model'] / cell['prompt'] / f"rep{cell['repetition']}" / cell['interface'] / cell['case_id']


def has_model_output(path):
    for raw in path.read_text().splitlines():
        try:
            event = json.loads(raw)
        except json.JSONDecodeError:
            continue
        if event.get('item', {}).get('type') in ('agent_message', 'command_execution', 'reasoning'):
            return True
    return False


def run_one(cell, frozen):
    directory = session_directory(cell)
    metadata_file = directory / 'metadata.json'
    if metadata_file.exists():
        if load(metadata_file)['freeze_sha256'] != digest(FREEZE):
            raise ValueError('session freeze mismatch')
        return cell, load(metadata_file)['status']
    directory.mkdir(parents=True, exist_ok=True)
    tool = f'{shlex.quote(sys.executable)} {shlex.quote(str(Path(__file__).resolve()))}'
    prompt = PROMPTS[cell['prompt']].read_text().format(
        tool_command=tool, interface=cell['interface'], case_id=cell['case_id'])
    (directory / 'prompt.txt').write_text(prompt)
    attempts = []
    for attempt in range(1, 4):
        target = directory / f'attempt{attempt}'
        target.mkdir(exist_ok=False)
        command = ['codex', 'exec', '-', '--ephemeral', '--ignore-user-config',
                   '--ignore-rules', '--skip-git-repo-check', '-C', str(EMPTY),
                   '-s', 'read-only', '-m', frozen['models'][cell['model']],
                   '-c', 'model_reasoning_effort="medium"', '--output-schema', str(SCHEMA),
                   '--json', '-o', str(target / 'result.json')]
        start = time.monotonic()
        started = timestamp()
        timed_out = False
        with (target / 'transcript.jsonl').open('w') as out, (target / 'stderr.txt').open('w') as err:
            try:
                process = subprocess.run(command, input=prompt, text=True, stdout=out, stderr=err,
                                         timeout=frozen['timeout_seconds'], check=False)
                returncode = process.returncode
            except subprocess.TimeoutExpired:
                returncode, timed_out = -1, True
        output = has_model_output(target / 'transcript.jsonl')
        success = returncode == 0 and (target / 'result.json').exists()
        status = 'complete' if success else ('model-failure' if output or timed_out else 'infrastructure-failure')
        record = {'attempt': attempt, 'started_utc': started, 'elapsed_seconds': time.monotonic() - start,
                  'returncode': returncode, 'timeout': timed_out, 'model_output': output, 'status': status}
        write(target / 'attempt.json', record)
        attempts.append(record)
        if success or output or timed_out:
            break
    metadata = cell | {'freeze_sha256': digest(FREEZE), 'status': status, 'attempts': attempts,
                       'final_attempt': attempts[-1]['attempt']}
    write(metadata_file, metadata)
    return cell, status


def run(limit):
    frozen = verified_freeze()
    EMPTY.mkdir(exist_ok=True)
    cells = frozen['matrix'] if limit is None else frozen['matrix'][:limit]
    with ThreadPoolExecutor(max_workers=frozen['workers']) as pool:
        futures = [pool.submit(run_one, cell, frozen) for cell in cells]
        for future in as_completed(futures):
            cell, status = future.result()
            print('/'.join(map(str, cell.values())), status, flush=True)


def parsed_commands(path, cell):
    calls, forbidden, usage = [], [], {}
    for raw in path.read_text().splitlines():
        try:
            event = json.loads(raw)
        except json.JSONDecodeError:
            forbidden.append('malformed-transcript-event')
            continue
        if event.get('type') == 'turn.completed':
            usage = event.get('usage', {})
        item = event.get('item', {})
        if event.get('type') != 'item.completed' or item.get('type') != 'command_execution':
            continue
        command = item.get('command', '')
        try:
            words = shlex.split(command)
            if len(words) == 3 and words[1] in ('-lc', '-c') and Path(words[0]).name in ('bash', 'sh'):
                words = shlex.split(words[2])
            if len(words) < 3 or not Path(words[0]).name.startswith('python') or Path(words[1]).name != Path(__file__).name:
                raise ValueError('not an allowed tool')
            arguments = words[2:]
            if arguments == ['query', '--interface', cell['interface'], '--case', cell['case_id']]:
                calls.append(('query', None))
            elif len(arguments) == 5 and arguments[:3] == ['measure', '--case', cell['case_id']] and arguments[3] == '--tp' and arguments[4] in ('1', '2', '4'):
                calls.append(('measure', int(arguments[4])))
            else:
                raise ValueError('unexpected tool arguments')
            if item.get('exit_code') not in (0, None):
                forbidden.append('failed-tool-call')
        except (ValueError, IndexError):
            forbidden.append(command)
    return calls, forbidden, usage


def outcome(task, result, measurements, permitted=True):
    action = task['frozen_action']
    selected = result.get('selected_tp')
    if action == 'ESTIMATE':
        valid = result.get('decision') == 'SELECT' and selected == task['certified_tp'] and not measurements
    elif action == 'MEASURE':
        valid = result.get('decision') == 'SELECT' and selected == task['measured_optimum_tp'] and sorted(measurements) == sorted(task['required_measurements'])
    else:
        valid = result.get('decision') == 'STOP' and selected is None and not measurements
    report = result.get('measurements_used', [])
    report_valid = isinstance(report, list) and all(type(x) is int for x in report) and sorted(report) == sorted(measurements)
    supported = action != 'UNSUPPORTED'
    selected_valid = supported and result.get('decision') == 'SELECT' and selected in task['candidates']
    regret = None
    if selected_valid:
        times = task['measured_us']
        regret = 100 * (times[str(selected)] / min(times.values()) - 1)
    return {
        'action': action, 'supported': supported,
        'protocol_valid': bool(permitted and valid and report_valid and len(measurements) == len(set(measurements))),
        'exact': bool(selected_valid and selected == task['measured_optimum_tp']),
        'complete_measure': action == 'MEASURE' and sorted(measurements) == sorted(task['required_measurements']),
        'correct_stop': action == 'UNSUPPORTED' and valid,
        'measurement_calls': len(measurements),
        'unnecessary_measurements': sum(tp not in task['required_measurements'] for tp in measurements) + sum(measurements.count(tp)-1 for tp in set(measurements) if tp in task['required_measurements']),
        'missing_measurements': len(set(task['required_measurements']) - set(measurements)),
        'regret_percent': regret,
    }


def summary(rows):
    import statistics
    result = {'sessions': len(rows), 'supported_sessions': sum(r['supported'] for r in rows)}
    for key in ('protocol_valid', 'exact', 'complete_measure', 'correct_stop', 'measurement_calls', 'unnecessary_measurements', 'missing_measurements'):
        result[key] = sum(r[key] for r in rows)
    result['maximum_regret_percent'] = max((r['regret_percent'] for r in rows if r['regret_percent'] is not None), default=None)
    result['elapsed_seconds_median'] = statistics.median(r['elapsed_seconds'] for r in rows) if rows else None
    result['tokens'] = {key: sum(r['usage'].get(key, 0) for r in rows) for key in ('input_tokens', 'cached_input_tokens', 'output_tokens')}
    result['status_counts'] = {s: sum(r['status'] == s for r in rows) for s in sorted({r['status'] for r in rows})}
    return result


def score(check=False):
    frozen = load(FREEZE)
    tasks, rows = expected_tasks(), []
    for cell in frozen['matrix']:
        directory = session_directory(cell)
        metadata = load(directory / 'metadata.json')
        target = directory / f"attempt{metadata['final_attempt']}"
        calls, forbidden, usage = parsed_commands(target / 'transcript.jsonl', cell)
        try:
            result = load(target / 'result.json')
        except (OSError, json.JSONDecodeError):
            result = {}
        measurements = [tp for cmd, tp in calls if cmd == 'measure']
        permitted = (metadata['status'] == 'complete' and not forbidden and calls[:1] == [('query', None)]
                     and sum(cmd == 'query' for cmd, _ in calls) == 1)
        rows.append(cell | outcome(tasks[cell['case_id']], result, measurements, permitted) | {
            'status': metadata['status'], 'actual_measurements': measurements,
            'disallowed_commands': forbidden, 'usage': usage,
            'elapsed_seconds': sum(a['elapsed_seconds'] for a in metadata['attempts']),
            'attempts': len(metadata['attempts']),
        })
    controls = []
    for case_id, task in tasks.items():
        result = controller(case_id)
        controls.append({'case_id': case_id} | outcome(task, result, result['measurements_used']))
    output = {
        'schema': 'matched-evidence-v4-results', 'freeze_sha256': digest(FREEZE),
        'models': frozen['models'], 'codex_version': frozen['codex_version'], 'rows': rows,
        'summary': {i: summary([r for r in rows if r['interface'] == i]) for i in INTERFACES},
        'by_model': {m: {i: summary([r for r in rows if r['model'] == m and r['interface'] == i]) for i in INTERFACES} for m in frozen['models']},
        'by_prompt': {p: {i: summary([r for r in rows if r['prompt'] == p and r['interface'] == i]) for i in INTERFACES} for p in PROMPTS},
        'controller': {'cases': len(controls), 'protocol_valid': sum(r['protocol_valid'] for r in controls),
                       'supported_cases': sum(r['supported'] for r in controls), 'exact': sum(r['exact'] for r in controls),
                       'measurement_calls': sum(r['measurement_calls'] for r in controls), 'rows': controls},
    }
    if check:
        if output != load(RESULT):
            raise ValueError('saved matched-evidence scores differ from transcripts')
    else:
        write(RESULT, output)
    print(json.dumps({k: output[k] for k in ('summary', 'controller')}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest='command', required=True)
    sub.add_parser('freeze')
    q = sub.add_parser('query')
    q.add_argument('--interface', choices=INTERFACES, required=True)
    q.add_argument('--case', required=True)
    m = sub.add_parser('measure')
    m.add_argument('--case', required=True)
    m.add_argument('--tp', type=int, choices=(1, 2, 4), required=True)
    r = sub.add_parser('run')
    r.add_argument('--limit', type=int)
    s = sub.add_parser('score')
    s.add_argument('--check', action='store_true')
    args = parser.parse_args()
    if args.command == 'freeze': freeze()
    elif args.command == 'query': print(json.dumps(query(args.case, args.interface), sort_keys=True))
    elif args.command == 'measure': print(json.dumps(measure(args.case, args.tp), sort_keys=True))
    elif args.command == 'run': run(args.limit)
    elif args.command == 'score': score(args.check)


if __name__ == '__main__':
    main()

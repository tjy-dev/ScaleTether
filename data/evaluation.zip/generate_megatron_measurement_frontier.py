#!/usr/bin/env python3
"""Reconstruct the TP endpoint-measurement frontier from frozen H100 runs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import statistics


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "evidence" / "scaletether" / "paired-tp-v8.json"
OUTPUT = ROOT / "evidence" / "scaletether" / "megatron-measurement-frontier.json"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    evidence = json.loads(INPUT.read_text(encoding="utf-8"))
    rows = {
        (row["hidden_size"], row["source_tp"], row["target_tp"]): row
        for row in evidence["rows"]
    }
    tasks: list[dict[str, object]] = []
    for hidden in sorted({key[0] for key in rows}):
        tp12 = rows[(hidden, 1, 2)]
        tp24 = rows[(hidden, 2, 4)]
        for first, second in zip(tp12["runs"], tp24["runs"], strict=True):
            if first["outer_ordinal"] != second["outer_ordinal"]:
                raise SystemExit("paired transitions have different outer ordinals")
            true = {
                1: float(first["source_median_us"]),
                2: float(first["target_median_us"]),
                4: float(second["target_median_us"]),
            }
            if abs(true[2] - float(second["source_median_us"])) > 1.0e-9:
                raise SystemExit("TP2 endpoint differs between paired transitions")
            ratio12 = float(tp12["frozen_predicted_ratio"])
            ratio24 = float(tp24["frozen_predicted_ratio"])
            policies = {
                "measure-all": {"measurements": 3, "times": dict(true)},
                "sequential": {
                    "measurements": 2,
                    "times": {1: true[1], 2: true[2], 4: true[2] * ratio24},
                },
                "recursive": {
                    "measurements": 1,
                    "times": {
                        1: true[1],
                        2: true[1] * ratio12,
                        4: true[1] * ratio12 * ratio24,
                    },
                },
            }
            best = min(true, key=true.get)
            task_policies: dict[str, object] = {}
            for name, policy in policies.items():
                predicted = policy["times"]
                selected = min(predicted, key=predicted.get)
                task_policies[name] = {
                    "endpoint_measurements": policy["measurements"],
                    "selected_tp": selected,
                    "selected_time_us": true[selected],
                    "regret_percent": 100.0 * (true[selected] / true[best] - 1.0),
                    "tp4_signed_error_percent": 100.0
                    * (predicted[4] - true[4])
                    / true[4],
                }
            tasks.append(
                {
                    "hidden_size": hidden,
                    "outer_ordinal": first["outer_ordinal"],
                    "true_endpoint_medians_us": {str(k): v for k, v in true.items()},
                    "physically_fastest_tp": best,
                    "policies": task_policies,
                }
            )

    summary: dict[str, object] = {}
    for name in ("measure-all", "sequential", "recursive"):
        records = [task["policies"][name] for task in tasks]
        summary[name] = {
            "tasks": len(records),
            "endpoint_measurements_per_task": records[0]["endpoint_measurements"],
            "correct_fastest_selections": sum(
                record["regret_percent"] == 0.0 for record in records
            ),
            "maximum_regret_percent": max(record["regret_percent"] for record in records),
            "median_tp4_absolute_error_percent": statistics.median(
                abs(record["tp4_signed_error_percent"]) for record in records
            ),
            "maximum_tp4_absolute_error_percent": max(
                abs(record["tp4_signed_error_percent"]) for record in records
            ),
        }
    output = {
        "schema": "scaletether-megatron-measurement-frontier-v1",
        "source": {"path": str(INPUT.relative_to(ROOT)), "sha256": sha256(INPUT)},
        "task_definition": (
            "Select the fastest of TP1, TP2, and TP4 for one held-out hidden-size "
            "run; calibration anchors are common prerequisites and excluded."
        ),
        "interpretation": (
            "Retrospective policy analysis over prospectively recorded endpoint "
            "predictions; it is not a language-model-agent evaluation."
        ),
        "tasks": tasks,
        "summary": summary,
    }
    encoded = json.dumps(output, indent=2, sort_keys=True) + "\n"
    if args.check:
        if not OUTPUT.is_file() or OUTPUT.read_text(encoding="utf-8") != encoded:
            raise SystemExit("measurement-frontier evidence is stale")
    else:
        OUTPUT.write_text(encoded, encoding="utf-8")
    print(f"output={OUTPUT}")
    print(f"sha256={sha256(OUTPUT)} check={str(args.check).lower()}")


if __name__ == "__main__":
    main()

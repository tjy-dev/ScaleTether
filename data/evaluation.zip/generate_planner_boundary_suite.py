#!/usr/bin/env python3
"""Generate the deterministic three-action planner boundary suite."""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parents[1]))

from scaletether.planner_contract import (
    ESTIMATE,
    MEASURE,
    UNSUPPORTED,
    CalibrationDomain,
    PlannerRequest,
    decide,
)


OUTPUTS = (
    ROOT / "evidence" / "scaletether" / "planner-boundary-suite.json",
    ROOT / "artifact" / "evidence" / "planner-boundary-suite.json",
)


def build() -> dict:
    domain = CalibrationDomain(
        framework_identity="megatron-core:pinned",
        runtime_identity="cuda-nccl:pinned",
        accelerator_identity="h100:pinned",
        sequence_length=2048,
        minimum_hidden_size=3072,
        maximum_hidden_size=6144,
        tp_transitions=frozenset({(1, 2), (2, 4)}),
        pp_schedules=frozenset({"1f1b-noninterleaved"}),
    )
    base = PlannerRequest(
        framework_identity=domain.framework_identity,
        runtime_identity=domain.runtime_identity,
        accelerator_identity=domain.accelerator_identity,
        sequence_length=domain.sequence_length,
        hidden_size=4096,
        transformation="tp",
        source_tp=1,
        target_tp=2,
    )
    cases = (
        ("in-domain stable request", base, ESTIMATE, "calibration-domain-accepted"),
        (
            "incomplete source measurements",
            replace(base, source_measurements_complete=False),
            MEASURE,
            "source-measurements-incomplete",
        ),
        (
            "unstable source measurements",
            replace(base, source_measurements_stable=False),
            MEASURE,
            "source-measurements-unstable",
        ),
        (
            "hidden-size extrapolation",
            replace(base, hidden_size=8192),
            UNSUPPORTED,
            "hidden-size-extrapolation",
        ),
        (
            "unsupported TP transition",
            replace(base, source_tp=4, target_tp=8),
            UNSUPPORTED,
            "tp-transition-unsupported",
        ),
        (
            "mismatched Megatron identity",
            replace(base, framework_identity="megatron-core:other"),
            UNSUPPORTED,
            "framework-identity-mismatch",
        ),
        (
            "unsupported PP schedule",
            replace(
                base,
                transformation="pp",
                source_tp=None,
                target_tp=None,
                pp_schedule="interleaved-custom",
            ),
            UNSUPPORTED,
            "pp-schedule-unsupported",
        ),
        (
            "hardware identity mismatch",
            replace(base, accelerator_identity="blackwell:unmeasured"),
            UNSUPPORTED,
            "accelerator-identity-mismatch",
        ),
        (
            "software identity mismatch",
            replace(base, runtime_identity="cuda-nccl:other"),
            UNSUPPORTED,
            "runtime-identity-mismatch",
        ),
    )
    rows = []
    for label, request, expected_action, expected_reason in cases:
        returned = decide(domain, request)
        if (returned.action, returned.reason_code) != (
            expected_action,
            expected_reason,
        ):
            raise RuntimeError(f"boundary contract changed for {label}")
        rows.append(
            {
                "query": label,
                "expected_action": expected_action,
                "returned_action": returned.action,
                "reason_code": returned.reason_code,
                "passed": True,
            }
        )
    return {
        "schema": "scaletether-planner-boundary-suite-v1",
        "implementation": "scaletether.planner_contract.decide",
        "case_count": len(rows),
        "passed_case_count": sum(row["passed"] for row in rows),
        "rows": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    payload = json.dumps(build(), indent=2, sort_keys=True) + "\n"
    for path in OUTPUTS:
        if args.check:
            if not path.is_file() or path.read_text(encoding="utf-8") != payload:
                raise SystemExit(f"stale planner boundary suite: {path}")
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(payload, encoding="utf-8")
    print(f"planner boundary suite: {len(build()['rows'])}/{len(build()['rows'])} passed")


if __name__ == "__main__":
    main()

"""Prospective H100 timing bracket for a Megatron MLP layout rewrite."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import sys
import time

import torch
import torch.distributed as dist


SCHEMA = "scaletether-megatron-layout-timing-bracket-v1"


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tensor-parallel-size", type=int, required=True, choices=(2, 4))
    parser.add_argument("--sequence-length", type=int, default=2048)
    parser.add_argument("--micro-batch-size", type=int, default=1)
    parser.add_argument("--warmup-repetitions", type=int, default=10)
    parser.add_argument("--measured-repetitions", type=int, default=20)
    parser.add_argument("--anchor-hidden", type=int, nargs=2, default=(1024, 4096))
    parser.add_argument("--target-hidden", type=int, default=2048)
    parser.add_argument(
        "--prediction-method",
        choices=("ratio-log-interpolation", "target-log-interpolation"),
        default="ratio-log-interpolation",
    )
    parser.add_argument("--order", choices=("ascending", "descending"), required=True)
    parser.add_argument("--outer-repetition", type=int, required=True)
    parser.add_argument("--cpu-affinity-map")
    parser.add_argument("--output-dir", type=Path, required=True)
    return parser.parse_args()


def atomic_json(path: Path, document: dict[str, object]) -> str:
    encoded = (json.dumps(document, indent=2, sort_keys=True) + "\n").encode()
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_bytes(encoded)
    temporary.replace(path)
    return hashlib.sha256(encoded).hexdigest()


def apply_affinity(specification: str | None, rank: int) -> list[int]:
    if specification is None:
        return sorted(os.sched_getaffinity(0))
    groups = specification.split(";")
    if len(groups) <= rank:
        raise ValueError("CPU affinity map has fewer groups than local ranks")
    cpus: set[int] = set()
    for part in groups[rank].split(","):
        if "-" in part:
            low, high = map(int, part.split("-", 1))
            cpus.update(range(low, high + 1))
        else:
            cpus.add(int(part))
    os.sched_setaffinity(0, cpus)
    return sorted(os.sched_getaffinity(0))


def load_megatron() -> tuple[object, ...]:
    os.environ["NO_VCS_VERSION"] = "1"
    root = Path(os.environ["MEGATRON_ROOT"]).resolve()
    sys.path.insert(0, str(root))
    from megatron.core import parallel_state
    from megatron.core.model_parallel_config import ModelParallelConfig
    from megatron.core.tensor_parallel.layers import ColumnParallelLinear, RowParallelLinear
    from megatron.core.tensor_parallel.mappings import scatter_to_tensor_model_parallel_region
    from megatron.core.tensor_parallel.random import model_parallel_cuda_manual_seed
    return (parallel_state, ModelParallelConfig, ColumnParallelLinear,
            RowParallelLinear, scatter_to_tensor_model_parallel_region,
            model_parallel_cuda_manual_seed)


def main() -> None:
    args = arguments()
    if args.measured_repetitions != 20:
        raise ValueError("the frozen protocol requires exactly 20 retained repetitions")
    anchors = tuple(sorted(args.anchor_hidden))
    if not anchors[0] < args.target_hidden < anchors[1]:
        raise ValueError("target hidden size must be strictly inside the anchor bracket")
    if any(value % args.tensor_parallel_size for value in (*anchors, args.target_hidden)):
        raise ValueError("all hidden sizes must divide tensor parallel size")
    (parallel_state, config_type, column_type, row_type, scatter_input,
     seed_model_parallel) = load_megatron()
    local_rank = int(os.environ.get("LOCAL_RANK", "0"))
    affinity = apply_affinity(args.cpu_affinity_map, local_rank)
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    torch.cuda.set_device(local_rank)
    device = torch.device("cuda", local_rank)
    dist.init_process_group("nccl", device_id=device)
    try:
        if dist.get_rank() == 0:
            args.output_dir.mkdir(parents=True, exist_ok=False)
        dist.barrier()
        if dist.get_world_size() != args.tensor_parallel_size:
            raise ValueError("world size must equal tensor parallel size")
        parallel_state.initialize_model_parallel(
            tensor_model_parallel_size=args.tensor_parallel_size,
            pipeline_model_parallel_size=1,
            create_gloo_process_groups=False,
        )
        seed_model_parallel(1234 + args.outer_repetition)
        config = config_type(
            tensor_model_parallel_size=args.tensor_parallel_size,
            pipeline_model_parallel_size=1,
            params_dtype=torch.float32,
        )

        def measure(layout: str, hidden: int) -> dict[str, object]:
            ffn = 4 * hidden
            init = torch.nn.init.xavier_uniform_

            class Mlp(torch.nn.Module):
                def __init__(self) -> None:
                    super().__init__()
                    if layout == "column-gelu-row":
                        self.first = column_type(hidden, ffn, config=config,
                            init_method=init, bias=False, gather_output=False)
                        self.second = row_type(ffn, hidden, config=config,
                            init_method=init, bias=False, input_is_parallel=True,
                            skip_bias_add=False)
                    else:
                        self.first = row_type(hidden, ffn, config=config,
                            init_method=init, bias=False, input_is_parallel=True,
                            skip_bias_add=False)
                        self.second = column_type(ffn, hidden, config=config,
                            init_method=init, bias=False, gather_output=True)

                def forward(self, value: torch.Tensor) -> torch.Tensor:
                    if layout == "row-gelu-column":
                        value = scatter_input(value)
                    value, _ = self.first(value)
                    value = torch.nn.functional.gelu(value)
                    value, _ = self.second(value)
                    return value

            torch.manual_seed(20260809 + hidden)
            module = Mlp().cuda()
            optimizer = torch.optim.AdamW(module.parameters(), lr=1e-3)
            inputs = torch.randn(args.sequence_length, args.micro_batch_size,
                                 hidden, device=device, requires_grad=True)
            targets = torch.randn_like(inputs)

            def step() -> None:
                optimizer.zero_grad(set_to_none=True)
                inputs.grad = None
                output = module(inputs)
                torch.nn.functional.mse_loss(output, targets).backward()
                optimizer.step()

            for _ in range(args.warmup_repetitions):
                step()
            torch.cuda.synchronize()
            samples: list[float] = []
            for _ in range(args.measured_repetitions):
                start = torch.cuda.Event(enable_timing=True)
                end = torch.cuda.Event(enable_timing=True)
                start.record()
                step()
                end.record()
                end.synchronize()
                elapsed = torch.tensor(start.elapsed_time(end) * 1000.0, device=device)
                dist.all_reduce(elapsed, op=dist.ReduceOp.MAX)
                samples.append(float(elapsed.item()))
            result = {
                "layout": layout, "hidden_size": hidden, "ffn_hidden_size": ffn,
                "samples_us": samples, "median_us": statistics.median(samples),
                "rank_envelope": "maximum-rank CUDA-event duration",
            }
            del optimizer, module, inputs, targets
            torch.cuda.empty_cache()
            dist.barrier()
            return result

        records: dict[str, dict[str, object]] = {}
        anchor_order = anchors if args.order == "ascending" else anchors[::-1]
        for hidden in anchor_order:
            records[f"source_h{hidden}"] = measure("column-gelu-row", hidden)
            records[f"target_h{hidden}"] = measure("row-gelu-column", hidden)

        heldout_source_left = measure("column-gelu-row", args.target_hidden)
        records["heldout_source_left"] = heldout_source_left
        ratios = {
            hidden: float(records[f"target_h{hidden}"]["median_us"])
            / float(records[f"source_h{hidden}"]["median_us"])
            for hidden in anchors
        }
        interpolation_weight = math.log(args.target_hidden / anchors[0]) / math.log(
            anchors[1] / anchors[0]
        )
        if args.prediction_method == "ratio-log-interpolation":
            predicted_ratio = math.exp(
                math.log(ratios[anchors[0]]) * (1.0 - interpolation_weight)
                + math.log(ratios[anchors[1]]) * interpolation_weight
            )
            predicted_target_us = (
                float(heldout_source_left["median_us"]) * predicted_ratio
            )
        else:
            target_anchor_medians = {
                hidden: float(records[f"target_h{hidden}"]["median_us"])
                for hidden in anchors
            }
            predicted_target_us = math.exp(
                math.log(target_anchor_medians[anchors[0]])
                * (1.0 - interpolation_weight)
                + math.log(target_anchor_medians[anchors[1]])
                * interpolation_weight
            )
            predicted_ratio = (
                predicted_target_us / float(heldout_source_left["median_us"])
            )
        freeze = {
            "schema": "scaletether-megatron-layout-timing-freeze-v1",
            "created_unix_ns": time.time_ns(),
            "target_observed": False,
            "method": args.prediction_method,
            "anchor_hidden_sizes": list(anchors),
            "target_hidden_size": args.target_hidden,
            "anchor_ratios": {str(k): v for k, v in ratios.items()},
            "interpolation_weight": interpolation_weight,
            "predicted_ratio": predicted_ratio,
            "heldout_source_median_us": heldout_source_left["median_us"],
            "predicted_target_median_us": predicted_target_us,
            "timing_ape_gate_percent": 5.0,
            "source_control_drift_gate_percent": 3.0,
        }
        freeze_sha = ""
        if dist.get_rank() == 0:
            freeze_sha = atomic_json(args.output_dir / "prediction-freeze.json", freeze)
        objects: list[object] = [freeze_sha]
        dist.broadcast_object_list(objects, src=0)
        freeze_sha = str(objects[0])
        dist.barrier()

        target_started_ns = time.time_ns()
        heldout_target = measure("row-gelu-column", args.target_hidden)
        records["heldout_target"] = heldout_target
        records["heldout_source_right"] = measure("column-gelu-row", args.target_hidden)
        actual = float(heldout_target["median_us"])
        ape = abs(predicted_target_us - actual) / actual * 100.0
        left = float(heldout_source_left["median_us"])
        right = float(records["heldout_source_right"]["median_us"])
        drift = abs(right - left) / statistics.median((left, right)) * 100.0
        result = {
            "schema": SCHEMA,
            "tensor_parallel_size": args.tensor_parallel_size,
            "sequence_length": args.sequence_length,
            "micro_batch_size": args.micro_batch_size,
            "outer_repetition": args.outer_repetition,
            "anchor_order": args.order,
            "warmup_repetitions": args.warmup_repetitions,
            "measured_repetitions": args.measured_repetitions,
            "prediction_freeze_sha256": freeze_sha,
            "target_started_unix_ns": target_started_ns,
            "prediction_absolute_percentage_error": ape,
            "source_control_drift_percent": drift,
            "timing_gate": "passed" if ape <= 5.0 else "failed",
            "source_control_gate": "passed" if drift <= 3.0 else "failed",
            "rank0_cpu_affinity": affinity if dist.get_rank() == 0 else None,
            "records": records,
        }
        if dist.get_rank() == 0:
            atomic_json(args.output_dir / "result.json", result)
            print("SCALETETHER_LAYOUT_TIMING=" + json.dumps(result, sort_keys=True))
    finally:
        if dist.is_initialized():
            parallel_state.destroy_model_parallel()
            dist.destroy_process_group()


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Generate the manuscript's quantitative tables from paper-local evidence."""

from __future__ import annotations

import argparse
import json
import math
import random
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence" / "scaletether"
OUTPUT = ROOT / "generated"


def load(name: str) -> dict:
    return json.loads((EVIDENCE / name).read_text(encoding="utf-8"))


def scientific_tex(value: float, digits: int = 3) -> str:
    coefficient, exponent = f"{value:.{digits}e}".split("e")
    return rf"${coefficient}\times10^{{{int(exponent)}}}$"


def fixed_resource_models(hidden: int, sequence: int) -> tuple[dict[int, float], ...]:
    """Reconstruct the three frozen models from the sealed V4 calibration."""

    freeze = load("fixed-resource-megatron-search-v4-freeze.json")
    corner_logs = {
        (
            int(gate["hidden_size"]),
            int(gate["sequence_length"]),
            int(gate["tensor_parallel_size"]),
        ): math.log(float(gate["centered_ratio"]))
        for gate in freeze["contrast_gates"]
    }
    calibration = ((512, 512), (1536, 512), (512, 2048), (1536, 2048))

    def interpolate(tp: int, *, logarithmic: bool) -> float:
        if logarithmic:
            x = math.log(hidden / 512) / math.log(3)
            y = math.log(sequence / 512) / math.log(4)
        else:
            x = (hidden - 512) / 1024
            y = (sequence - 512) / 1536
        values = {(h, s): corner_logs[(h, s, tp)] for h, s in calibration}
        return math.exp(
            values[(512, 512)] * (1 - x) * (1 - y)
            + values[(1536, 512)] * x * (1 - y)
            + values[(512, 2048)] * (1 - x) * y
            + values[(1536, 2048)] * x * y
        )

    nearest_h, nearest_s = min(
        calibration,
        key=lambda point: (
            (math.log(hidden / point[0]) / math.log(3)) ** 2
            + (math.log(sequence / point[1]) / math.log(4)) ** 2,
            point[0],
            point[1],
        ),
    )
    return (
        {
            1: 1.0,
            2: interpolate(2, logarithmic=True),
            4: interpolate(4, logarithmic=True),
        },
        {
            1: 1.0,
            2: interpolate(2, logarithmic=False),
            4: interpolate(4, logarithmic=False),
        },
        {
            1: 1.0,
            2: math.exp(corner_logs[(nearest_h, nearest_s, 2)]),
            4: math.exp(corner_logs[(nearest_h, nearest_s, 4)]),
        },
    )


def fixed_resource_model_choices(hidden: int, sequence: int) -> tuple[int, int, int]:
    return tuple(
        min((1, 2, 4), key=ratios.__getitem__)
        for ratios in fixed_resource_models(hidden, sequence)
    )


def validate_fixed_resource_v7_selection(tasks: list[dict]) -> None:
    """Reproduce the sealed representative and stress coordinate selection."""

    previously_measured = {(512, 512), (1536, 512), (512, 2048), (1536, 2048)}
    for name in (
        "fixed-resource-megatron-search-v4.json",
        "fixed-resource-megatron-search-v5.json",
        "fixed-resource-megatron-search-v6.json",
    ):
        previously_measured.update(
            (int(row["hidden_size"]), int(row["sequence_length"]))
            for row in load(name)["tasks"]
        )
    candidates = []
    for hidden in (768, 1024, 1280):
        for sequence in range(640, 1921, 128):
            if (hidden, sequence) in previously_measured:
                continue
            models = fixed_resource_models(hidden, sequence)
            choices = tuple(min((1, 2, 4), key=model.__getitem__) for model in models)
            ranked = sorted(models[0].values())
            candidates.append(
                {
                    "coordinate": (hidden, sequence),
                    "choice_count": len(set(choices)),
                    "margin": 100.0 * (ranked[1] / ranked[0] - 1.0),
                    "action": "ESTIMATE" if len(set(choices)) == 1 else "MEASURE",
                }
            )
    representative = random.Random(20260809).sample(candidates, 12)
    representative_coordinates = {row["coordinate"] for row in representative}
    stress = sorted(
        (
            row
            for row in candidates
            if row["coordinate"] not in representative_coordinates
        ),
        key=lambda row: (
            -row["choice_count"],
            row["margin"],
            row["coordinate"][0],
            row["coordinate"][1],
        ),
    )[:6]
    expected = [("representative", row) for row in representative] + [
        ("stress", row) for row in stress
    ]
    observed = [
        (
            row["cohort"],
            (int(row["hidden_size"]), int(row["sequence_length"])),
            row["action"],
        )
        for row in tasks
    ]
    reconstructed = [
        (cohort, row["coordinate"], row["action"]) for cohort, row in expected
    ]
    if observed != reconstructed:
        raise SystemExit("table generation failed: V7 fixed-seed selection changed")


def paired_tp_v7_table() -> str:
    evidence = load("paired-tp-v7.json")
    rows = evidence["rows"]
    if evidence["status"] != "passed" or len(rows) != 4:
        raise SystemExit("table generation failed: paired-TP primary outcome changed")

    lines = [
        r"\begin{table*}[t]",
        r"\caption{Primary prospective paired-TP timing result on H100. Predictions",
        r"were stored from H1536 and H2560 source measurements before five",
        r"separately scheduled runs of each held-out target. The criteria required",
        r"median error $\leq10\%$, at least 4/5 runs within 10\%, and maximum variation",
        r"in the measured ratio $\leq10\%$. All four transitions passed.}",
        r"\label{tab:paired-tp-v7}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{5pt}",
        r"\begin{tabular}{lrrrrr}",
        r"\toprule",
        r"Held-out target & Predicted ratio & Measured median & Median error & Runs $\leq10\%$ & Max. variation \\",
        r"\midrule",
    ]
    for row in rows:
        label = (
            f"H{row['target_hidden_size']}, "
            + r"TP$"
            + row["tp_transition"].replace("-to-", r"\rightarrow")
            + r"$"
        )
        lines.append(
            f"{label} & {row['predicted_ratio']:.6f} & "
            f"{row['observed_median_ratio']:.6f} & "
            f"{row['median_outer_prediction_error_percent']:.3f}\\% & "
            f"{row['outer_observations_within_10_percent']}/5 & "
            f"{row['maximum_outer_ratio_deviation_percent']:.3f}\\% \\\\"
        )
    aggregate = evidence["aggregate"]
    lines.extend(
        (
            r"\midrule",
            f"All contrasts & -- & -- & mean {aggregate['mean_contrast_median_outer_error_percent']:.3f}\\% & "
            f"{aggregate['outer_observations_within_10_percent']}/"
            f"{aggregate['outer_observations_total']} & "
            f"worst {aggregate['worst_contrast_median_outer_error_percent']:.3f}\\% \\\\",
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table*}",
            "",
        )
    )
    return "\n".join(lines)


def paired_tp_v7_baselines_table() -> str:
    evidence = load("paired-tp-v7-baselines.json")
    rows = evidence["rows"]
    if (
        evidence["status"] != "target-blind-secondary-comparison"
        or evidence["timing_status"]
        != "sealed-after-acquisition-completed-before-target-observations-opened"
        or len(rows) != 5
    ):
        raise SystemExit("table generation failed: paired-TP baseline status changed")

    lines = [
        r"\begin{table*}[t]",
        r"\caption{Target-blind comparison on four paired-TP ratio predictions.",
        r"Only ScaleTether was preregistered before source acquisition; every method",
        r"was stored before target results were read.}",
        r"\label{tab:paired-tp-baselines}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{2pt}",
        r"\begin{tabular}{@{}lcrrrr@{}}",
        r"\toprule",
        r"Method & Preregistered? & Mean transition-median APE & Maximum transition-median APE & Runs $\leq10\%$ & Transitions passing \\",
        r"\midrule",
    ]
    for row in rows:
        method = row["method"]
        preregistered = (
            "Yes" if method == "ScaleTether log-hidden interpolation" else "No"
        )
        lines.append(
            f"{method} & {preregistered} & {row['mean_contrast_median_outer_error_percent']:.3f}\\% & "
            f"{row['worst_contrast_median_outer_error_percent']:.3f}\\% & "
            f"{row['outer_observations_within_10_percent']}/"
            f"{row['outer_observations_total']} & "
            f"{row['contrasts_meeting_numerical_gates']}/"
            f"{row['contrasts_total']} \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""))
    return "\n".join(lines)


def paired_tp_v8_baselines_table() -> str:
    evidence = load("paired-tp-v8-baselines.json")
    rows = evidence["rows"]
    if (
        evidence["schema"] != "scaletether-paper-paired-tp-v8-baselines-v1"
        or evidence["status"] != "secondary-target-blind-comparison"
        or evidence["target_blind"] is not True
        or evidence["absolute_and_ratio_ape_are_identical"] is not True
        or len(rows) != 5
    ):
        raise SystemExit("table generation failed: V8 comparison status changed")

    lines = [
        r"\begin{table*}[t]",
        r"\caption{Comparison of the proposed interpolation with four target-blind",
        r"baselines on 20 H100 observations. All predictions were stored before",
        r"target measurement; mean and maximum summarize four transition medians.}",
        r"\label{tab:paired-tp-baselines}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{@{}lrrrr@{}}",
        r"\toprule",
        r"Method & Mean APE & Maximum APE & Runs $\leq10\%$ & Transitions passed \\",
        r"\midrule",
    ]
    for row in rows:
        method = (
            row["method"] + " (proposed)"
            if row["preregistered_primary"]
            else row["method"]
        )
        lines.append(
            f"{method} & "
            f"{row['mean_transition_median_ape_percent']:.2f}\\% & "
            f"{row['maximum_transition_median_ape_percent']:.2f}\\% & "
            f"{row['runs_within_declared_error_gate']}/20 & "
            f"{row['transitions_meeting_same_error_counts']}/4 \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""))
    return "\n".join(lines)


def paired_tp_v8_primary_table() -> str:
    evidence = load("paired-tp-v8.json")
    replication = load("h100-v21-robust-dp-pp-decision.json")
    rows = evidence["rows"]
    if (
        evidence.get("schema") != "scaletether-paper-paired-tp-v8-primary-v1"
        or evidence.get("status") != "passed"
        or len(rows) != 4
    ):
        raise SystemExit("table generation failed: V8 primary outcome changed")
    if (
        replication.get("action") != "COMPLETE"
        or replication.get("timing_status") != "passed"
        or set(replication.get("families", {})) != {"DP-B", "PP-B"}
    ):
        raise SystemExit("table generation failed: DP/PP replication changed")

    lines = [
        r"\begin{table*}[t]",
        r"\caption{H100 timing results. TP rows use a same-width source-side endpoint measured before the target; DP and PP rows use the left control in each bracket. Predicted and observed times and APE report medians across five independent allocations. $H$ denotes hidden size and $S$ sequence length.}",
        r"\label{tab:paired-tp-v8-primary}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{6pt}",
        r"\begin{tabular}{@{}p{0.34\textwidth}rrrrr@{}}",
        r"\toprule",
        r"Prediction task & Pred. (ms) & Obs. (ms) & Median APE & Worst APE & Runs $\leq10\%$ \\",
        r"\midrule",
    ]
    for row in rows:
        worst = max(run["absolute_target_time_ape_percent"] for run in row["runs"])
        label = (
            f"Predict TP{row['target_tp']} from measured TP{row['source_tp']}, "
            + f"H={row['hidden_size']:,}"
        )
        predicted = [run["predicted_target_median_us"] / 1000 for run in row["runs"]]
        observed = [run["target_median_us"] / 1000 for run in row["runs"]]
        apes = [run["absolute_target_time_ape_percent"] for run in row["runs"]]
        lines.append(
            f"{label} & {statistics.median(predicted):.2f} & "
            f"{statistics.median(observed):.2f} & {statistics.median(apes):.2f}\\% & "
            f"{worst:.2f}\\% & {row['runs_within_declared_error_gate']}/5 \\\\"
        )
    for family, label in (
        ("DP-B", r"Predict DP2 from measured DP1, S=2,048"),
        ("PP-B", r"Predict PP2 from measured PP1, S=2,048"),
    ):
        row = replication["families"][family]
        metrics = row["eligible_metrics"]
        errors = [100 * item["pretarget_absolute_error_fraction"] for item in metrics]
        ratios = {item["frozen_ratio"] for item in metrics}
        if (
            row["acquisition_decision"]["eligible_attempts"] != 5
            or row["timing_status"] != "passed"
            or len(metrics) != 5
            or len(ratios) != 1
        ):
            raise SystemExit(f"table generation failed: {family} outcome changed")
        predicted = [
            item["predicted_iteration_device_envelope_us"] / 1000 for item in metrics
        ]
        observed = [
            item["actual_iteration_device_envelope_us"] / 1000 for item in metrics
        ]
        ratios.pop()
        lines.append(
            f"{label} & {statistics.median(predicted):.2f} & {statistics.median(observed):.2f} & "
            f"{statistics.median(errors):.2f}\\% & {max(errors):.2f}\\% & "
            f"{sum(error <= 10 for error in errors)}/5 \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""))
    return "\n".join(lines)


def measurement_frontier_prospective_table() -> str:
    evidence = load("megatron-measurement-frontier-prospective.json")
    tasks = evidence.get("tasks", [])
    expected_tasks = [
        (hidden, outer) for hidden in (3584, 5632) for outer in range(1, 6)
    ]
    if (
        evidence.get("schema") != "scaletether-megatron-measurement-frontier-score-v1"
        or len(tasks) != 10
        or [(row.get("hidden_size"), row.get("outer_ordinal")) for row in tasks]
        != expected_tasks
    ):
        raise SystemExit(
            "table generation failed: prospective measurement frontier changed"
        )

    rows: dict[str, dict[str, object]] = {}
    for policy_name in ("sequential", "recursive"):
        tp2_errors: list[float] = []
        tp4_errors: list[float] = []
        regrets: list[float] = []
        endpoint_counts: set[int] = set()
        correct = 0
        for task in tasks:
            true_times = {
                int(tp): float(value)
                for tp, value in task["true_endpoint_medians_us"].items()
            }
            if set(true_times) != {1, 2, 4} or any(
                value <= 0 for value in true_times.values()
            ):
                raise SystemExit("table generation failed: invalid endpoint timing")
            fastest = min(true_times, key=true_times.get)
            policy = task["policies"][policy_name]
            selected = int(policy["selected_tp"])
            regret = 100.0 * (true_times[selected] / true_times[fastest] - 1.0)
            if (
                int(task["physically_fastest_tp"]) != fastest
                or bool(policy["correct_fastest_selection"]) != (selected == fastest)
                or abs(float(policy["regret_percent"]) - regret) > 1.0e-10
            ):
                raise SystemExit(
                    "table generation failed: frontier decision cannot be reconstructed"
                )
            correct += selected == fastest
            regrets.append(regret)
            endpoint_counts.add(int(policy["endpoint_measurements"]))
            tp2_errors.append(float(policy["tp2_absolute_error_percent"]))
            tp4_errors.append(float(policy["tp4_absolute_error_percent"]))
        if len(endpoint_counts) != 1:
            raise SystemExit("table generation failed: inconsistent endpoint count")
        rows[policy_name] = {
            "endpoints": endpoint_counts.pop(),
            "correct": correct,
            "tp2_median": statistics.median(tp2_errors),
            "tp2_maximum": max(tp2_errors),
            "tp4_median": statistics.median(tp4_errors),
            "tp4_maximum": max(tp4_errors),
            "maximum_regret": max(regrets),
        }

    lines = [
        r"\begin{table}[t]",
        r"\caption{Prospective endpoint-measurement frontier on ten H100 tasks:",
        r"five runs each at H=3,584 and H=5,632. Policies were stored before",
        r"unmeasured endpoints ran; error entries are median/maximum APE.}",
        r"\label{tab:measurement-frontier}",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{@{}lrrrr@{}}",
        r"\toprule",
        r"Policy & Measured & Correct & TP2 APE & TP4 APE \\",
        r"\midrule",
        r"Measure all & 3/3 & 10/10 & -- & -- \\",
    ]
    for policy_name, label in (
        ("sequential", "Sequential"),
        ("recursive", "Recursive"),
    ):
        row = rows[policy_name]
        tp2 = (
            "--"
            if policy_name == "sequential"
            else f"{row['tp2_median']:.4f}/{row['tp2_maximum']:.4f}\\%"
        )
        lines.append(
            f"{label} & {row['endpoints']}/3 & {row['correct']}/10 & "
            f"{tp2} & "
            f"{row['tp4_median']:.4f}/{row['tp4_maximum']:.4f}\\% \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table}", ""))
    return "\n".join(lines)


def fixed_resource_megatron_search_v4_table() -> str:
    """Render the fixed-four-H100 search without admitting hand-entered results."""

    path = EVIDENCE / "fixed-resource-megatron-search-v4.json"
    if not path.is_file():
        return "\n".join(
            (
                r"\begin{table*}[t]",
                r"\caption{Fixed-resource H100 search. This table is generated only after",
                r"the eight untouched target allocations have completed and the stored",
                r"predictions have been scored.}",
                r"\label{tab:fixed-resource-v4}",
                r"\centering",
                r"\fbox{\parbox{0.92\textwidth}{\centering",
                r"V4 target score pending: \texttt{evidence/scaletether/",
                r"fixed-resource-megatron-search-v4.json}. No target result has been",
                r"entered manually.}}",
                r"\end{table*}",
                "",
            )
        )

    evidence = json.loads(path.read_text(encoding="utf-8"))
    tasks = evidence.get("tasks", [])
    summary = evidence.get("summary", {})
    if (
        evidence.get("schema") != "scaletether-fixed-resource-megatron-search-score-v4"
        or evidence.get("primary_metric") != "within-allocation-ratio"
        or evidence.get("cross_node_absolute_ape_reported") is not False
        or len(tasks) != 8
        or [row.get("task_id") for row in tasks] != list(range(1, 9))
        or summary.get("tasks") != 8
    ):
        raise SystemExit("table generation failed: fixed-resource V4 score changed")

    lines = [
        r"\begin{table}[!ht]",
        r"\caption{Held-out fixed-resource search. Every candidate uses four H100s",
        r"and global batch four. TP2 and TP4 columns report signed error in their",
        r"predicted ratios to TP1 within the same allocation.}",
        r"\label{tab:fixed-resource-v4}",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{@{}lrrrr@{}}",
        r"\toprule",
        r"H/S & TP sel./best & Regret & TP2 err. & TP4 err. \\",
        r"\midrule",
    ]
    for row in tasks:
        errors = row.get("signed_ratio_errors_percent", {})
        required = {
            "timing_action": "ESTIMATE",
            "selected_tp": row.get("selected_tp"),
            "physically_fastest_tp": row.get("physically_fastest_tp"),
        }
        if (
            required["timing_action"] != "ESTIMATE"
            or required["selected_tp"] not in (1, 2, 4)
            or required["physically_fastest_tp"] not in (1, 2, 4)
            or row.get("correct_selection")
            != (required["selected_tp"] == required["physically_fastest_tp"])
            or set(errors) != {"2", "4"}
        ):
            raise SystemExit("table generation failed: invalid fixed-resource V4 task")
        lines.append(
            f"{row['hidden_size']:,}/{row['sequence_length']:,} & "
            f"{row['selected_tp']}/{row['physically_fastest_tp']} & "
            f"{float(row['regret_percent']):.2f}\\% & "
            f"{float(errors['2']):+.2f}\\% & {float(errors['4']):+.2f}\\% \\\\"
        )
    correct = sum(bool(row["correct_selection"]) for row in tasks)
    regrets = [float(row["regret_percent"]) for row in tasks]
    absolute_errors = [
        abs(float(row["signed_ratio_errors_percent"][tp]))
        for row in tasks
        for tp in ("2", "4")
    ]
    recomputed = {
        "correct_selections": correct,
        "selection_accuracy_percent": 100.0 * correct / len(tasks),
        "median_regret_percent": statistics.median(regrets),
        "maximum_regret_percent": max(regrets),
        "median_absolute_ratio_error_percent": statistics.median(absolute_errors),
        "maximum_absolute_ratio_error_percent": max(absolute_errors),
    }
    if any(
        not math.isclose(
            float(summary.get(key, math.nan)), value, rel_tol=0.0, abs_tol=1.0e-12
        )
        for key, value in recomputed.items()
    ):
        raise SystemExit("table generation failed: fixed-resource V4 summary differs")

    lines.extend(
        (
            r"\midrule",
            f"All tasks & {correct}/8 correct & "
            f"max {recomputed['maximum_regret_percent']:.2f}\\% & "
            rf"\multicolumn{{2}}{{r}}{{abs. err. med./max "
            f"{recomputed['median_absolute_ratio_error_percent']:.2f}\\%/"
            f"{recomputed['maximum_absolute_ratio_error_percent']:.2f}\\%}} \\\\",
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
        )
    )
    return "\n".join(lines)


def fixed_resource_megatron_search_v4_summary() -> str:
    path = EVIDENCE / "fixed-resource-megatron-search-v4.json"
    if not path.is_file():
        return (
            r"\newcommand{\fixedresourceheadline}{\revisioncolor{[Fixed-resource V4 "
            r"result pending evidence-generated score.]}}" + "\n"
        )
    evidence = json.loads(path.read_text(encoding="utf-8"))
    if evidence.get("schema") != "scaletether-fixed-resource-megatron-search-score-v4":
        raise SystemExit("table generation failed: fixed-resource V4 summary changed")
    summary = evidence["summary"]
    return (
        r"\newcommand{\fixedresourceheadline}{The fixed-resource search selected "
        + f"{int(summary['correct_selections'])}/8 measured optima with "
        + f"{float(summary['maximum_regret_percent']):.2f}\\% maximum regret and "
        + f"{float(summary['median_absolute_ratio_error_percent']):.2f}\\% median "
        + r"absolute error in predicted candidate-time ratios.}"
        + "\n"
    )


def fixed_resource_megatron_search_v4_analysis_tables() -> str:
    evidence = load("fixed-resource-megatron-search-v4-analysis.json")
    if (
        evidence.get("schema")
        != "scaletether-fixed-resource-megatron-search-v4-analysis-v1"
    ):
        raise SystemExit("table generation failed: fixed-resource analysis changed")
    baselines = evidence.get("baselines", [])
    if (
        len(baselines) != 7
        or baselines[0].get("method") != "ScaleTether log-coordinate bilinear"
    ):
        raise SystemExit("table generation failed: fixed-resource baselines changed")
    labels = {
        "ScaleTether log-coordinate bilinear": "ScaleTether (log bilinear)",
        "raw-coordinate bilinear": "Raw-coordinate bilinear",
        "nearest calibration corner": "Nearest corner",
        "global median ratio": "Global median ratio",
        "always TP1": "Always TP1",
        "always TP2": "Always TP2",
        "always TP4": "Always TP4",
    }
    lines = [
        r"\begin{table*}[!t]",
        r"\caption{Target-blind alternatives on the same eight held-out allocations.",
        r"Ratio error is unavailable for fixed-choice policies.}",
        r"\label{tab:fixed-resource-baselines}",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{4pt}",
        r"\begin{tabular}{@{}lrrrrr@{}}",
        r"\toprule",
        r"Method & Exact best & Within 1\% & Median regret & Max. regret & Ratio APE med./max \\",
        r"\midrule",
    ]
    for row in baselines:
        ratio = (
            "--"
            if row["median_absolute_ratio_error_percent"] is None
            else (
                f"{row['median_absolute_ratio_error_percent']:.2f}/"
                f"{row['maximum_absolute_ratio_error_percent']:.2f}\\%"
            )
        )
        lines.append(
            f"{labels[row['method']]} & {row['exact_best']}/8 & "
            f"{row['within_one_percent_of_best']}/8 & "
            f"{row['median_regret_percent']:.2f}\\% & "
            f"{row['maximum_regret_percent']:.2f}\\% & {ratio} \\\\"
        )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""))
    return "\n".join(lines)


def fixed_resource_megatron_search_v4_cost_table() -> str:
    evidence = load("fixed-resource-megatron-search-v4-analysis.json")
    economics = evidence.get("economics", {})
    v7 = load("fixed-resource-megatron-search-v7.json")
    v7_accounting = v7.get("accounting", {})
    if (
        economics.get("break_even_queries") != 11
        or v7_accounting.get("representative_break_even_query_count") != 44
    ):
        raise SystemExit("table generation failed: fixed-resource economics changed")
    calibration = float(economics["calibration_h100_gpu_seconds"])
    estimate_direct_rate = float(economics["average_direct_query_h100_gpu_seconds"])
    representative_direct_rate = (
        float(v7_accounting["representative_direct_gpu_seconds"]) / 12
    )
    representative_request_rate = (
        float(v7_accounting["representative_requested_gpu_seconds"]) / 12
    )
    lines = [
        r"\begin{table}[!ht]",
        r"\caption{Projected H100 break-even after sharing one measured calibration.",
        r"The estimate-only rate uses the original eight-query cohort; the selective",
        r"rate uses the 12-query representative cohort.}",
        r"\label{tab:fixed-resource-cost}",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.8pt}",
        r"\begin{tabular}{@{}lrrr@{}}",
        r"\toprule",
        r"Policy (observed cohort) & Direct/query & Requested/query & Break-even \\",
        r"\midrule",
        f"Estimate only (8 queries) & {estimate_direct_rate:,.1f} & 0.0 & 11 \\\\",
        f"Selective (12 representative) & {representative_direct_rate:,.1f} & "
        f"{representative_request_rate:,.1f} & 44 \\\\",
        r"\bottomrule",
        r"\end{tabular}",
        r"\vspace{2pt}",
        r"\begin{minipage}{0.97\columnwidth}\scriptsize",
        f"Calibration cost $C_0={calibration:,.0f}$ GPU-s. For direct rate $d$ and "
        r"policy-requested rate $m$, break-even is $\lceil C_0/(d-m)\rceil$.",
        r"\end{minipage}",
        r"\end{table}",
        "",
    ]
    return "\n".join(lines)


def fixed_resource_megatron_search_v6_table() -> str:
    """Render the frozen selective policy and independently recorded accounting."""

    evidence = load("fixed-resource-megatron-search-v6.json")
    accounting = load("fixed-resource-megatron-search-v6-accounting.json")
    tasks = evidence.get("tasks", [])
    account_rows = accounting.get("tasks", [])
    if (
        evidence.get("schema") != "scaletether-fixed-resource-megatron-selective-score-v6"
        or len(tasks) != 6
        or [row.get("task_id") for row in tasks] != list(range(1, 7))
        or accounting.get("schema")
        != "scaletether-fixed-resource-megatron-selective-accounting-v6"
        or [row.get("task_id") for row in account_rows] != list(range(1, 7))
    ):
        raise SystemExit("table generation failed: selective V6 evidence changed")

    rows = []
    for row, account in zip(tasks, account_rows):
        if row["action"] != account["action"] or row["action"] not in {
            "ESTIMATE",
            "MEASURE",
        }:
            raise SystemExit("table generation failed: V6 action/accounting mismatch")
        choices = fixed_resource_model_choices(
            int(row["hidden_size"]), int(row["sequence_length"])
        )
        expected_action = "ESTIMATE" if len(set(choices)) == 1 else "MEASURE"
        if row["action"] != expected_action:
            raise SystemExit("table generation failed: V6 disagreement gate changed")
        action = "E" if row["action"] == "ESTIMATE" else "M"
        final_tp = (
            row["selected_tp"]
            if row["action"] == "ESTIMATE"
            else row["physically_fastest_tp"]
        )
        final_regret = (
            row["emitted_regret_percent"] if row["action"] == "ESTIMATE" else 0.0
        )
        rows.append(
            f"{row['hidden_size']:,}/{row['sequence_length']:,} & "
            f"{row['blind_log_selected_tp']}/{row['physically_fastest_tp']} & "
            f"{float(row['blind_log_regret_percent']):.2f}\\% & {action} & "
            f"{final_tp} & {float(final_regret):.2f}\\%"
        )

    lines = [
        r"\begin{table*}[!t]",
        r"\caption{Prospective selective-policy evaluation. E=\textsc{Estimate}; M=\textsc{Measure}, which acquires TP1/2/4 and selects the measured best.}",
        r"\label{tab:fixed-resource-v6}",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{3.4pt}",
        r"\begin{tabular}{@{}lrrrrr@{\hspace{8pt}}lrrrrr@{}}",
        r"\toprule",
        r"H/S & Pred./best & Regret & Act. & Final & Regret & H/S & Pred./best & Regret & Act. & Final & Regret \\",
        r"\midrule",
    ]
    for left, right in zip(rows[:3], rows[3:]):
        lines.append(f"{left} & {right} \\\\")

    gpus = int(accounting["gpus_per_target_allocation"])
    direct = gpus * sum(float(row["ru_wallclock_seconds"]) for row in account_rows)
    requested = gpus * sum(
        float(row["ru_wallclock_seconds"])
        for row in account_rows
        if row["action"] == "MEASURE"
    )
    calibration = float(accounting["calibration_h100_gpu_seconds"])
    selective_total = calibration + requested
    saved = direct - requested
    saved_percent = 100.0 * saved / direct
    lines.extend(
        (
            r"\bottomrule",
            r"\end{tabular}",
            r"\vspace{2pt}",
            r"\begin{minipage}{0.98\textwidth}\scriptsize",
            f"Direct six-query acquisition: {direct:,.0f} GPU-s. Selective acquisition "
            f"after shared calibration: {requested:,.0f} GPU-s (saving {saved_percent:.1f}\\%). "
            f"Calibration plus requested measurements: {selective_total:,.0f} GPU-s.",
            r"\end{minipage}",
            r"\end{table*}",
            "",
        )
    )
    return "\n".join(lines)


def fixed_resource_megatron_search_v7_table() -> str:
    """Render the expanded target-blind selective-policy evaluation."""

    evidence = load("fixed-resource-megatron-search-v7.json")
    summary = evidence.get("summary", {})
    accounting = evidence.get("accounting", {})
    if (
        evidence.get("schema") != "scaletether-fixed-resource-megatron-selective-score-v7"
        or len(evidence.get("tasks", [])) != 18
        or not summary.get("accepted")
        or not all(summary.get("protocol_gates", {}).values())
        or len(accounting.get("scheduler_records", [])) != 18
        or any(
            row.get("failed") != 0 or row.get("exit_status") != 0
            for row in accounting["scheduler_records"]
        )
    ):
        raise SystemExit("table generation failed: selective V7 evidence changed")

    tasks = evidence["tasks"]
    validate_fixed_resource_v7_selection(tasks)
    lines = [
        r"\begin{table*}[!t]",
        r"\caption{All 18 target-blind selective-policy cases. R denotes the fixed-seed representative sample and S the model-disagreement/margin stress set. L/R/N are the TP choices of log-coordinate, raw-coordinate, and nearest-corner models. \textsc{Measure} acquires TP1/2/4; hence Final/best reports the selected measured optimum.}",
        r"\label{tab:fixed-resource-v7}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{4.2pt}",
        r"\begin{tabular}{@{}rrlrrrrr@{}}",
        r"\toprule",
        r"Set & H/S & L/R/N & Blind/best & Blind regret & Action & Final/best & Candidate CV max. \\",
        r"\midrule",
    ]
    for row in tasks:
        choices = fixed_resource_model_choices(
            int(row["hidden_size"]), int(row["sequence_length"])
        )
        final_tp = (
            row["selected_tp"]
            if row["action"] == "ESTIMATE"
            else row["physically_fastest_tp"]
        )
        cohort = "R" if row["cohort"] == "representative" else "S"
        action = (
            r"\textsc{Estimate}" if row["action"] == "ESTIMATE" else r"\textsc{Measure}"
        )
        lines.append(
            f"{cohort} & {row['hidden_size']:,}/{row['sequence_length']:,} & "
            f"{choices[0]}/{choices[1]}/{choices[2]} & "
            f"{row['blind_log_selected_tp']}/{row['physically_fastest_tp']} & "
            f"{float(row['blind_log_regret_percent']):.2f}\\% & {action} & "
            f"{final_tp}/{row['physically_fastest_tp']} & "
            f"{max(float(value) for value in row['within_candidate_cv_percent'].values()):.2f}\\% \\\\"
        )
    lines.extend(
        (
            r"\bottomrule",
            r"\end{tabular}",
            r"\vspace{2pt}",
            r"\begin{minipage}{0.98\textwidth}\scriptsize",
            f"R: 12 queries, 3 estimates/9 measurements, 3/3 estimated optima; "
            f"S: 6 queries, 2 estimates/4 measurements, 2/2 estimated optima. "
            f"All 7 unconditional choices above 1\\% regret were withheld. Direct acquisition: "
            f"{accounting['direct_gpu_seconds']:,.0f} GPU-s; policy-requested acquisition after "
            f"shared calibration: {accounting['requested_gpu_seconds']:,.0f} GPU-s "
            f"(saving {accounting['marginal_savings_percent']:.1f}\\%).",
            r"\end{minipage}",
            r"\end{table*}",
            "",
        )
    )
    return "\n".join(lines)


def megatron_layout_v4_table() -> str:
    evidence = load("megatron-layout-h100-matrix-v4.json")
    cells = evidence.get("cells", [])
    expected = {
        (hidden, 4 * hidden, sequence, tp, 1)
        for hidden in (1024, 2048)
        for tp in (2, 4)
        for sequence in (1024, 2048)
    }
    coordinates = {
        (
            cell.get("hidden_size"),
            cell.get("ffn_hidden_size"),
            cell.get("sequence_length"),
            cell.get("tensor_parallel_size"),
            cell.get("micro_batch_size"),
        )
        for cell in cells
    }
    if (
        evidence.get("schema") != "scaletether-megatron-layout-h100-matrix-v4-evidence"
        or len(cells) != 8
        or coordinates != expected
    ):
        raise SystemExit("table generation failed: layout v4 matrix changed")

    gate_names = {
        "forward_output",
        "input_gradient",
        "row_weight_gradient",
        "column_weight_gradient",
        "post_adamw_row_weight",
        "post_adamw_column_weight",
    }
    gradient_names = {"row_weight_gradient", "column_weight_gradient"}
    update_names = {"post_adamw_row_weight", "post_adamw_column_weight"}
    rank_comparisons = collective_events = numerical_gates = passed_gates = 0
    passed_cells = 0
    gradient_peak_errors: list[float] = []
    gradient_l2_errors: list[float] = []
    update_l2_errors: list[float] = []
    for cell in cells:
        tp = int(cell["tensor_parallel_size"])
        rank_results = cell.get("rank_results", [])
        comparisons = cell.get("rank_comparisons", [])
        if (
            cell.get("status") != "passed"
            or cell.get("validation_status") != "passed"
            or cell.get("timing_claim") != "not-evaluated"
            or {row.get("rank") for row in rank_results} != set(range(tp))
            or {row.get("rank") for row in comparisons} != set(range(tp))
        ):
            raise SystemExit("table generation failed: layout v4 cell did not pass")
        passed_cells += 1
        for rank in rank_results:
            gates = rank.get("gates", {})
            if rank.get("status") != "passed" or set(gates) != gate_names:
                raise SystemExit("table generation failed: layout rank gates changed")
            for name, gate in gates.items():
                numerical_gates += 1
                if gate.get("status") == "passed" and gate.get("finite") is True:
                    passed_gates += 1
                else:
                    raise SystemExit(
                        "table generation failed: layout numerical gate failed"
                    )
                if name in gradient_names:
                    gradient_peak_errors.append(float(gate["max_relative_to_peak"]))
                    gradient_l2_errors.append(float(gate["relative_l2_error"]))
                if name in update_names:
                    if gate.get("update_finite") is not True:
                        raise SystemExit(
                            "table generation failed: layout update is non-finite"
                        )
                    update_l2_errors.append(float(gate["relative_update_l2_error"]))
        for comparison in comparisons:
            collectives = comparison.get("collectives", [])
            if comparison.get("status") != "exact" or len(collectives) != 4:
                raise SystemExit(
                    "table generation failed: layout collective comparison changed"
                )
            for index, collective in enumerate(collectives):
                if (
                    collective.get("collective")
                    != ("all_reduce" if index % 2 == 0 else "all_gather")
                    or collective.get("group_role") != "tp"
                    or collective.get("group_size") != tp
                    or int(collective.get("message_bytes", 0)) <= 0
                ):
                    raise SystemExit(
                        "table generation failed: layout collective record changed"
                    )
                collective_events += 1
            rank_comparisons += 1

    recomputed = {
        "cells": len(cells),
        "passed_cells": passed_cells,
        "rank_comparisons": rank_comparisons,
        "matched_collective_events": collective_events,
        "total_numerical_gates": numerical_gates,
        "passed_numerical_gates": passed_gates,
        "worst_gradient_peak_relative_error": max(gradient_peak_errors),
        "worst_gradient_relative_l2_error": max(gradient_l2_errors),
        "worst_adamw_update_relative_l2_error": max(update_l2_errors),
    }
    summary = evidence.get("summary", {})
    for key, value in recomputed.items():
        observed = summary.get(key)
        if isinstance(value, float):
            valid = isinstance(observed, (int, float)) and math.isclose(
                float(observed), value, rel_tol=0.0, abs_tol=1.0e-15
            )
        else:
            valid = observed == value
        if not valid:
            raise SystemExit(f"table generation failed: layout summary differs: {key}")

    return "\n".join(
        (
            r"\begin{table}[t]",
            r"\caption{H100 validation of the column/GELU/row-to-row/GELU/column MLP transformation.}",
            r"\label{tab:layout-v4}",
            r"\centering",
            r"\scriptsize",
            r"\setlength{\tabcolsep}{3pt}",
            r"\begin{tabular}{@{}lr@{}}",
            r"\toprule",
            r"Check & Result \\",
            r"\midrule",
            f"Configurations & {passed_cells}/{len(cells)} passed \\\\",
            f"Per-rank collective-event identity checks & {collective_events}/{collective_events} exact \\\\",
            f"Per-rank numerical checks & {passed_gates}/{numerical_gates} passed \\\\",
            f"Worst gradient error (peak-relative / relative $L_2$) & "
            f"{scientific_tex(recomputed['worst_gradient_peak_relative_error'])} / "
            f"{scientific_tex(recomputed['worst_gradient_relative_l2_error'])} \\\\",
            f"Worst AdamW-update relative $L_2$ error & "
            f"{recomputed['worst_adamw_update_relative_l2_error']:.6f} \\\\",
            r"\bottomrule",
            r"\end{tabular}",
            r"\end{table}",
            "",
        )
    )


def planner_boundary_table() -> str:
    evidence = load("planner-boundary-suite.json")
    rows = evidence["rows"]
    if (
        evidence.get("schema") != "scaletether-planner-boundary-suite-v1"
        or evidence.get("passed_case_count") != 9
        or len(rows) != 9
        or any(not row["passed"] for row in rows)
    ):
        raise SystemExit("table generation failed: planner boundary suite changed")
    action_counts = {
        action: sum(row["returned_action"] == action for row in rows)
        for action in ("ESTIMATE", "MEASURE", "UNSUPPORTED")
    }
    if action_counts != {"ESTIMATE": 1, "MEASURE": 2, "UNSUPPORTED": 6}:
        raise SystemExit("table generation failed: boundary action counts changed")
    lines = [
        r"\begin{table*}[t]",
        r"\caption{Deterministic boundary suite for all three planner actions.",
        r"Expected and returned actions agreed in 9/9 cases; the artifact reports",
        r"each query and its full reason code.}",
        r"\label{tab:planner-boundary}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{5pt}",
        r"\begin{tabular}{@{}p{0.31\textwidth}rp{0.14\textwidth}p{0.14\textwidth}p{0.24\textwidth}@{}}",
        r"\toprule",
        r"Query class & Cases & Expected & Returned & Reason-code family \\",
        r"\midrule",
        r"In-domain, stable evidence & 1 & \textsc{Estimate} & \textsc{Estimate} & \texttt{domain-accepted} \\",
        r"Incomplete or unstable source & 2 & \textsc{Measure} & \textsc{Measure} & \texttt{source-*} \\",
        r"Out-of-domain range, rule, or identity & 6 & \textsc{Unsupported} & \textsc{Unsupported} & typed range/rule/identity code \\",
    ]
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""))
    return "\n".join(lines)


def policy_table() -> str:
    studies = load("policy-table.json")["studies"]
    if [study["label"] for study in studies] != ["16 H100", "One node"]:
        raise SystemExit("table generation failed: policy study order changed")
    multi, one = studies
    lines = (
        r"\begin{table}[t]",
        r"\caption{{\revisioncolor CTA-setting results. A case is one workload/message-size pair;",
        r"slowdown is relative to the fastest measured setting for that case.}}",
        r"\label{tab:policy}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{3pt}",
        r"\begin{tabular}{@{}p{0.58\columnwidth}rr@{}}",
        r"\toprule",
        r"Result & 16 H100s & 4 H100s \\",
        r"\midrule",
        r"Workload/message-size decisions & 12 & 64 \\",
        r"CTA settings per case & 5 & 3 \\",
        r"Requested decision coverage & 80\% & 80\% \\",
        r"Held-out rows acquired after requests & 25/300 & 360/960 \\",
        r"Blind exact-best rate & 7/12 & 57/64 \\",
        r"Recommendations issued & 11/12 & 40/64 \\",
        r"Cases covered by uncertainty bound & 12/12 & 63/64 \\",
        f"Median setting-time error & {multi['median_point_ape_percent']:.2f}\\% & "
        f"{one['median_point_ape_percent']:.2f}\\% \\\\",
        f"Worst setting-time error & {multi['maximum_point_ape_percent']:.2f}\\% & "
        f"{one['maximum_point_ape_percent']:.2f}\\% \\\\",
        f"Worst recommended slowdown & {multi['maximum_emitted_regret_percent']:.2f}\\% & "
        f"{one['maximum_emitted_regret_percent']:.2f}\\% \\\\",
        f"Worst final regret after requests & {multi['maximum_emitted_regret_percent']:.2f}\\% & "
        f"{one['maximum_emitted_regret_percent']:.2f}\\% \\\\",
        r"Recommendations with $>1\%$ slowdown & 0/11 & 0/40 \\",
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table}",
        "",
    )
    return "\n".join(lines)


def planner_strategy_table() -> str:
    studies = load("planner-interface-study.json")["studies"]
    if [study["label"] for study in studies] != ["16 H100", "One node"]:
        raise SystemExit("table generation failed: planner study order changed")
    labels = {
        "blind-always-predict": "Blind predict",
        "status-aware-selective-request": "Status-aware",
        "always-measure": "Always measure",
    }
    study_labels = {"16 H100": "16 H100s", "One node": "One-node H100"}
    if any(study["requested_decision_error_coverage"] != 0.8 for study in studies):
        raise SystemExit("table generation failed: planner coverage target changed")
    lines = [
        r"\begin{table*}[t]",
        r"\caption{{\revisioncolor Full-grid planner replay. Uncertified counts decisions for which",
        r"blind prediction ignored a \textsc{Measure} action. A \textsc{Measure} action acquires the",
        r"complete candidate grid; exact best reports final-recommendation accuracy, including after",
        r"measurement; unsafe denotes measured slowdown above 1\%.}}",
        r"\label{tab:planner-replay}",
        r"\centering",
        r"\footnotesize",
        r"\setlength{\tabcolsep}{5pt}",
        r"\begin{tabular}{llrrrrrr}",
        r"\toprule",
        r"Study & Strategy & Uncertified & Requests & Rows & Exact best & Unsafe & Max. regret \\",
        r"\midrule",
    ]
    order = (
        "blind-always-predict",
        "status-aware-selective-request",
        "always-measure",
    )
    for study in studies:
        for index, key in enumerate(order):
            row = study["strategies"][key]
            study_label = study_labels[study["label"]] if index == 0 else ""
            lines.append(
                f"{study_label} & {labels[key]} & {row['uncertified_estimates']} & "
                f"{row['measurement_requests']} & {row['heldout_timing_rows_acquired']} & "
                f"{row['exact_best_recommendations']}/{row['final_recommendations']} & "
                f"{row['unsafe_final_recommendations_above_one_percent_regret']} & "
                f"{100 * row['maximum_final_regret_fraction']:.3f}\\% \\\\"
            )
        if study is not studies[-1]:
            lines.append(r"\addlinespace")
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table*}", ""))
    return "\n".join(lines)


def agentic_interface_table() -> str:
    evidence = load("agentic-interface-replication-v2.json")
    prose = load("agentic-interface-prose-v3.json")
    summary = evidence["summary"]
    labels = {
        "numeric-only": "TP only",
        "action-only": "Action",
        "full": "Action + evidence",
    }
    lines = [
        r"\begin{table}[t]",
        r"\caption{Offline agent compliance on 15 cases. Each main-interface row has 120 sessions: 40 per action. Protocol uses all 120; complete measurement and correct stop use the 40 \textsc{Measure} and 40 \textsc{Unsupported} sessions; exact choice uses the 80 supported sessions. Prose is a separate post-comparison follow-up.}",
        r"\label{tab:agentic-interface}",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2pt}",
        r"\begin{tabular}{@{}lrrrr@{}}",
        r"\toprule",
        r"Interface & Protocol & Complete meas. & Correct stop & Exact choice \\",
        r"\midrule",
    ]
    for interface in ("numeric-only", "action-only", "full"):
        row = summary[interface]
        episodes = row["episodes"]
        supported = row["supported_episodes"]
        measure_cases = episodes // 3
        unsupported_cases = episodes // 3
        lines.append(
            f"{labels[interface]} & {row['protocol_valid']}/{episodes} & "
            f"{measure_cases - row['ignored_measure']}/{measure_cases} & "
            f"{unsupported_cases - row['ignored_unsupported']}/{unsupported_cases} & "
            f"{row['exact_measured_optimum']}/{supported}" + r" \\"
        )
    row = prose["summary"]
    measure_cases = row["sessions"] // 3
    unsupported_cases = row["sessions"] // 3
    lines.append(r"\addlinespace")
    lines.append(
        f"Prose + evidence & {row['protocol_valid']}/{row['sessions']} & "
        f"{measure_cases - row['ignored_measure']}/{measure_cases} & "
        f"{unsupported_cases - row['ignored_unsupported']}/{unsupported_cases} & "
        f"{row['exact_measured_optimum']}/{row['supported_sessions']}" + r" \\"
    )
    lines.extend((r"\bottomrule", r"\end{tabular}", r"\end{table}", ""))
    return "\n".join(lines)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    outputs = {
        "fixed-resource-megatron-search-v4-summary.tex": fixed_resource_megatron_search_v4_summary(),
        "fixed-resource-megatron-search-v4-table.tex": fixed_resource_megatron_search_v4_table(),
        "fixed-resource-megatron-search-v4-analysis-table.tex": fixed_resource_megatron_search_v4_analysis_tables(),
        "fixed-resource-megatron-search-v4-cost-table.tex": fixed_resource_megatron_search_v4_cost_table(),
        "fixed-resource-megatron-search-v6-table.tex": fixed_resource_megatron_search_v6_table(),
        "fixed-resource-megatron-search-v7-table.tex": fixed_resource_megatron_search_v7_table(),
        "megatron-layout-h100-matrix-v4-table.tex": megatron_layout_v4_table(),
        "measurement-frontier-prospective-table.tex": measurement_frontier_prospective_table(),
        "paired-tp-v8-baselines-table.tex": paired_tp_v8_baselines_table(),
        "paired-tp-v8-primary-table.tex": paired_tp_v8_primary_table(),
        "policy-table.tex": policy_table(),
        "planner-strategy-table.tex": planner_strategy_table(),
        "planner-boundary-table.tex": planner_boundary_table(),
        "agentic-interface-table.tex": agentic_interface_table(),
    }
    OUTPUT.mkdir(exist_ok=True)
    for name, expected in outputs.items():
        path = OUTPUT / name
        if args.check:
            if not path.is_file() or path.read_text(encoding="utf-8") != expected:
                raise SystemExit(f"generated table is stale: {path}")
        else:
            path.write_text(expected, encoding="utf-8")
    print(f"generated_tables={len(outputs)} check={str(args.check).lower()}")


if __name__ == "__main__":
    main()

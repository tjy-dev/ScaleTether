"""Generate camera-ready agent tables directly from retained session scores."""
import json
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'evidence/scaletether'


def read(name):
    return json.loads((EVIDENCE / name).read_text())


def generate():
    replication = read('agentic-interface-replication-v2.json')['summary']
    prose = read('agentic-interface-prose-v3.json')['summary']
    lines = [r'\begin{table}[!t]',
             r'\caption{\crrev{Offline policy execution. Each model interface repeats 15 distinct cases; controller cases are counted once. Choice uses supported cases; Measure and Stop use cases requiring those actions. Studies use separate CLI versions.}}',
             r'\label{tab:camera-ready-agent-results}', r'\centering', r'\begin{cameraReady}',
             r'\footnotesize', r'\setlength{\tabcolsep}{3pt}',
             r'\begin{tabular}{@{}lrrrr@{}}', r'\toprule',
             r'Interface & Compliant & Choice & Measure & Stop \\',
             r'\midrule', r'\multicolumn{5}{l}{Original studies (CLI 0.147.0)} \\']
    for label, row in [('Numeric only', replication['numeric-only']),
                       ('Action only', replication['action-only']),
                       ('Action + evidence', replication['full']),
                       ('Prose guidance', prose)]:
        lines.append(f"{label} & {row['protocol_valid']}/120 & {row['exact_measured_optimum']}/80 & "
                     f"{40-row['ignored_measure']}/40 & {40-row['ignored_unsupported']}/40 " + r'\\')
    path = EVIDENCE / 'agentic-interface-matched-v4-results.json'
    if path.exists():
        matched = json.loads(path.read_text())
        lines.extend([r'\midrule', r'\multicolumn{5}{l}{Matched-evidence follow-up (CLI 0.154.0)} \\'])
        for label, key in [('Evidence only', 'evidence'), ('Evidence + action', 'action')]:
            row = matched['summary'][key]
            lines.append(f"{label} & {row['protocol_valid']}/{row['sessions']} & {row['exact']}/{row['supported_sessions']} & "
                         f"{row['complete_measure']}/40 & {row['correct_stop']}/40 " + r'\\')
        row = matched['controller']
        lines.append(f"Controller & {row['protocol_valid']}/{row['cases']} & {row['exact']}/{row['supported_cases']} & "
                     f"{sum(x['complete_measure'] for x in row['rows'])}/5 & {sum(x['correct_stop'] for x in row['rows'])}/5 " + r'\\')
    lines.extend([r'\bottomrule', r'\end{tabular}', r'\end{cameraReady}', r'\end{table}', ''])
    (ROOT/'generated/camera-ready-agent-results-table.tex').write_text('\n'.join(lines))
    with (EVIDENCE/'fixed-resource-v8-paper-package/cost.csv').open() as handle:
        costs = {row['quantity']: float(row['gpu_seconds']) for row in csv.DictReader(handle)}
    direct = costs['direct-primary-acquisition']
    lines = [r'\begin{table}[t]',
             r'\caption{\crrev{Scheduler-allocated H100 acquisition cost for 80 queries. Savings are relative to measuring all three candidates.}}',
             r'\label{tab:camera-ready-cost}', r'\centering', r'\begin{cameraReady}',
             r'\footnotesize', r'\begin{tabular}{@{}lrr@{}}', r'\toprule',
             r'Acquisition policy & GPU-hours & Saving \\', r'\midrule']
    for label, key in [('Measure all', 'direct-primary-acquisition'),
                       ('Selective + calibration', 'selective-cold-start'),
                       ('Selective, calibration reused', 'selective-requested-acquisition')]:
        lines.append(f'{label} & {costs[key]/3600:.2f} & {100*(1-costs[key]/direct):.1f}' + r'\% \\')
    lines.extend([r'\bottomrule', r'\end{tabular}', r'\end{cameraReady}', r'\end{table}', ''])
    (ROOT/'generated/camera-ready-cost-table.tex').write_text('\n'.join(lines))


if __name__ == '__main__':
    generate()

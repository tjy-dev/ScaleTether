#!/usr/bin/env python3
"""Run the preregistered 2x2x2 untyped-prose interface extension."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import json
from pathlib import Path
import subprocess


HERE = Path(__file__).resolve().parent


def repository_root() -> Path:
    """Locate docs both in the source tree and at reviewer-archive root."""
    source_root = HERE.parents[1]
    if (source_root / "docs/experiments").is_dir():
        return source_root
    if (HERE / "docs/experiments").is_dir():
        return HERE
    return source_root


CORPUS = HERE / "evidence/scaletether/agentic-interface-benchmark-v1.json"
SCHEMA = HERE / "agentic_interface_response.schema.json"
TOOL = HERE / "agentic_interface_prose_tool.py"
PREREG = repository_root() / "docs/experiments/preregistered-agentic-interface-prose-v3.md"
OUTPUT = HERE / "evidence/scaletether/agentic-interface-prose-runs-v3"
EMPTY_CWD = Path("/tmp/agentic-hpc-prose-v3-empty")
MODELS = {"sol": "gpt-5.6-sol", "terra": "gpt-5.6-terra"}
PROMPTS = {
    "standard": HERE / "agentic_interface_prose_prompt.txt",
    "concise": HERE / "agentic_interface_prose_prompt_concise.txt",
}
REPETITIONS = (1, 2)
CODEX_VERSION = "0.147.0"
REASONING_EFFORT = "medium"


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_one(
    model_label: str,
    prompt_label: str,
    repetition: int,
    case_id: str,
) -> tuple[str, int]:
    model = MODELS[model_label]
    prompt_path = PROMPTS[prompt_label]
    target = OUTPUT / model_label / prompt_label / f"rep{repetition}" / case_id
    target.mkdir(parents=True, exist_ok=True)
    result_path = target / "result.json"
    transcript_path = target / "transcript.jsonl"
    stderr_path = target / "stderr.txt"
    metadata_path = target / "metadata.json"
    metadata = {
        "case_id": case_id,
        "interface": "untyped-prose",
        "model": model,
        "model_label": model_label,
        "prompt_label": prompt_label,
        "repetition": repetition,
        "codex_cli_version": CODEX_VERSION,
        "model_reasoning_effort": REASONING_EFFORT,
        "temperature": "not exposed by Codex CLI",
        "random_seed": "not exposed by Codex CLI",
        "corpus_sha256": digest(CORPUS),
        "prompt_sha256": digest(prompt_path),
        "response_schema_sha256": digest(SCHEMA),
        "tool_sha256": digest(TOOL),
        "preregistration_sha256": digest(PREREG),
    }
    if result_path.exists() and transcript_path.exists() and metadata_path.exists():
        existing = json.loads(metadata_path.read_text())
        if existing == metadata | {"returncode": 0}:
            return "/".join(target.parts[-5:]), 0
        raise RuntimeError(f"existing episode metadata differs: {target}")

    prompt = prompt_path.read_text().format(tool_command=TOOL, case_id=case_id)
    command = [
        "codex", "exec", "-", "--ephemeral", "--ignore-user-config",
        "--ignore-rules", "--skip-git-repo-check", "-C", str(EMPTY_CWD),
        "-s", "read-only", "-m", model,
        "-c", f'model_reasoning_effort="{REASONING_EFFORT}"',
        "--output-schema", str(SCHEMA), "--json", "-o", str(result_path),
    ]
    with transcript_path.open("w") as stdout, stderr_path.open("w") as stderr:
        completed = subprocess.run(
            command, input=prompt, text=True, stdout=stdout, stderr=stderr, check=False
        )
    metadata_path.write_text(
        json.dumps(metadata | {"returncode": completed.returncode}, indent=2, sort_keys=True)
        + "\n"
    )
    return "/".join(target.parts[-5:]), completed.returncode


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    corpus = json.loads(CORPUS.read_text())
    EMPTY_CWD.mkdir(parents=True, exist_ok=True)
    jobs = [
        (model, prompt, repetition, task["case_id"])
        for model in MODELS
        for prompt in PROMPTS
        for repetition in REPETITIONS
        for task in corpus["tasks"]
    ]
    failures: list[tuple[str, int]] = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {executor.submit(run_one, *job): job for job in jobs}
        for future in as_completed(futures):
            label, returncode = future.result()
            print(f"{label}: exit={returncode}", flush=True)
            if returncode:
                failures.append((label, returncode))
    if failures:
        raise SystemExit(f"failed sessions: {failures}")
    print(f"agentic_interface_prose_sessions={len(jobs)}")


if __name__ == "__main__":
    main()

# Preregistered agentic-interface robustness replication v2

This replication tests whether the v1 typed-action result is specific to one
model invocation or one prompt wording. It reuses the already frozen 15-task
corpus without changing any task, action, measurement, or physical outcome.

Before executing any v2 model episode, the following matrix is fixed:

- models: `gpt-5.6-sol` and `gpt-5.6-terra`;
- prompts: the original v1 prompt and one concise semantic paraphrase;
- independent fresh sessions per cell: two;
- interfaces: numeric-only, typed action, and full evidence;
- tasks: all 15 cases in `agentic-interface-benchmark-v1.json`.

The complete matrix therefore contains 360 fresh episodes. Every episode uses
Codex CLI 0.147.0, medium reasoning, an ephemeral session, a read-only empty
working directory, and the existing response schema. The only permitted
commands are the case-specific query and measurement commands.

The primary outcomes are protocol-valid episodes, required MEASURE actions
completed, valid UNSUPPORTED stops, exact selections on supported tasks,
unrequested measurements, and maximum regret. Results are reported overall
and stratified by model and prompt. No cell may be deleted because it is
unfavorable. Transport failures before model output are reported separately
and rerun only when no model response was produced.

This is an offline tool-use replication. It does not test a live scheduler or
multi-step selection among alternative evidence-acquisition experiments.

# Matched-evidence agent-interface follow-up v4

This post-review follow-up reuses all 15 previously published offline cases.
The cases and their outcomes are already known; this is not a new prospective
physical validation. This protocol and the executable/prompt/schema hashes are
frozen before any v4 model episode. No H100 or scheduler allocation is needed.

## Question and conditions

Does an explicit action improve execution of a fixed planning policy when the
underlying evidence is identical? Both conditions expose the same candidate
list, workload, five support checks, calibration status, and the three models'
selected TP degrees. The `action` condition adds exactly one field, `action`;
the `evidence` condition omits it. Neither exposes target timings before a
measurement call, the measured winner, regret, or the corpus's expected action.
Boundary support facts are reconstructed from the existing synthetic boundary
cases; supported model choices come from the frozen V8 per-query records.
These are offline evidence presentations, not fresh graph validations.

Both conditions receive identical general policy instructions: stop if a
support check fails; otherwise measure all candidates when calibration is
missing/unstable or the models disagree; otherwise select the unanimous
winner without measurement. Additional action guidance does not change this
policy. The numeric-only and prose results from v2/v3 remain separate studies.

## Fixed matrix and execution

- Models: `gpt-5.6-sol` and `gpt-5.6-terra`.
- Reasoning effort: medium; actual CLI version recorded at freeze time.
- Prompts: standard and concise, shared byte-for-byte across conditions except
  the case-specific command's interface argument.
- Repetitions: two fresh ephemeral sessions per cell.
- Cases: all 15, with five each of Estimate, Measure, and Unsupported.
- Conditions: evidence and action; 240 planned sessions (120 per condition).
- Order: deterministic shuffle with seed 20260924.
- Four concurrent sessions; an empty read-only working directory; the existing
  output schema. Only the specified query and measurement commands are allowed.
- 180-second session timeout. Retain every attempt. Retry only a transport or
  infrastructure failure with no model output, at most twice. Model-produced
  failures and timeouts are outcomes and are not replaced.

Model availability is checked on a disjoint, nonexperimental probe before the
freeze. If the historic models are unavailable, record an amendment and the
replacement models before the freeze and run both conditions with them. Do not
pool new-model outcomes with the historic v2/v3 results.

## Controller and scoring

A deterministic reference controller consumes exactly the evidence interface
and the same measurement tool, applies the stated policy, and chooses the
minimum returned timing after measurement. It must not read the saved measured
winner or expected action to make its decision. Report its 15 cases separately
from the repeated model sessions.

The primary outcome is complete protocol compliance, scored from actual tool
calls and the final JSON: one initial query; no disallowed commands; correct
selection/stopping; all and only required measurements; no duplicate calls;
and an accurate measurements-used report. Scoring uses the frozen expected
action and target timings only after the session.

Secondary outcomes: correct choices among supported cases, complete Measure
procedures, correct Unsupported stops, unnecessary and missing measurement
calls, maximum selection regret, session elapsed time, and reported input,
cached-input, and output tokens. Report per-model and per-prompt counts. Keep
infrastructure failures visible and state the completed-session denominator.
Do not interpret 120 repeated sessions as 120 distinct workloads. Latency is
descriptive under concurrent execution; no API-dollar or scheduler-savings
claim follows from it. Zero observed differences do not establish equivalence.

## Reporting and freeze

Retain the rendered prompts, tool payloads, transcripts, final responses,
attempt metadata, software versions, and SHA-256 identities. Freeze the source
tables, evidence payloads, runner/scorer, prompts, schema, and this protocol
before model execution. Report all results, including ties and negative results.
The follow-up tests an interface for a fixed policy; it cannot establish that
an LLM is needed or that agents handle live scheduling or measurement failures.

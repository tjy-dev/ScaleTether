# Preregistered Megatron layout H100 timing experiment v3

V2 showed that ratio interpolation systematically overpredicted the TP4 target
even though the measured target-layout anchor times were smooth. V3 therefore
changes the generic predictor before observing its target: it log-linearly
interpolates target-layout median latency directly between two measured
anchors. It does not use the held-out source latency to scale that prediction;
the source sandwich remains a drift control.

The calibration anchors are hidden sizes 2,048 and 4,096. The new, untouched
target is hidden size 3,584, a conventional width divisible by both TP2 and
TP4. Sequence length remains 2,048, microbatch 1, FFN expansion 4x, and FP32.
For each TP size, five independent allocations use 10 warmups and 20 retained
measurements per endpoint, alternating anchor order. Each prediction is
atomically frozen before target execution.

The fixed gates remain 5% absolute percentage error and 3% following-source
drift. Every bracket is reported. V1 and V2 retain their original decisions.

# Preregistered untyped-prose interface extension v3

This follow-up was designed after inspecting the completed v2 replication. It
addresses one specific limitation of that study: the numeric-only interface
withheld the `MEASURE` and `UNSUPPORTED` information, so it was an information
ablation rather than a competitive untyped interface.

Before executing any v3 model session, the following design is fixed:

- tasks: the unchanged 15 cases in `agentic-interface-benchmark-v1.json`;
- models: `gpt-5.6-sol` and `gpt-5.6-terra`;
- prompts: one standard and one concise phrasing;
- independent fresh sessions per model--prompt cell: two;
- interface: an ordinary prose string carrying the same action, selected TP,
  required-measurement set, and reason information as the v2 full typed
  response;
- response schema and permitted measurement commands: unchanged.

The matrix contains 120 fresh sessions. Every session uses Codex CLI 0.147.0,
medium reasoning effort, an ephemeral session, and a read-only empty working
directory. The CLI does not expose temperature or random-seed controls, so the
two repetitions are independent sessions rather than deterministic reruns.

The primary outcomes are protocol-valid sessions, complete required
acquisition sets, valid unsupported stops, exact selections on supported
tasks, unnecessary acquisition-tool calls, and maximum regret. Results are
reported overall and by model and prompt. No cell may be removed because its
result is unfavorable. A transport failure may be rerun only if it occurs
before any model response is produced.

This extension isolates the effect of a machine-readable action field from the
effect of merely preserving the action information. It remains an offline
tool-compliance test over 15 unique planning cases. It does not test a live
scheduler, novel HPC problem generalization, or adaptive selection among
alternative evidence-acquisition experiments.

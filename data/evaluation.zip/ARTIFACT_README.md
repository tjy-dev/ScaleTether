# scaletether AgenticAI4HPC 2026 reviewer artifact

The supplementary archive is named `scaletether-reviewer-artifact.zip`. This
privacy-safe, CPU-only snapshot independently reconstructs all four
paired-TP transitions from their 20 independently scheduled runs, the held-out
DP/PP aggregates, the six-target structural comparison, and the 0/72 mutation
result. It also recomputes the Megatron endpoint-measurement frontier, validates
the 9/9 three-action boundary suite, checks acquisition-cost arithmetic, and
verifies the Chakra/ASTRA representation and executability records.

For the primary V8 study it includes the pre-acquisition freeze, all 80
per-allocation case records, the 40 repeated allocations summarized by target,
risk--coverage tables, scheduler-accounting summaries, the V4--V8 chronology,
the scripted planner-loop replay, the 360-session language-model interface
replication over 15 unique cases, and the separate 120-session untyped-prose
follow-up, with prompts, commands, responses, and scorers. It also includes the structural-campaign
identity map and independent-checker results needed to distinguish S-V7,
L-V16, and MLP-V4.

Run with Python 3.10 or newer:

```bash
python validate_scaletether_artifact.py
```

Reconstruct the 14 tables emitted by the common table generator and verify
byte-for-byte agreement with the archived outputs:

```bash
python generate_scaletether_tables.py --check
```

The independent artifact validator additionally recomputes the metrics in the
primary V8 table from its 80 case records and risk--coverage files. The table
generator also reconstructs the 12 fixed-seed representative coordinates
and six stress coordinates, verifies their cohort order and frozen
Estimate/Measure actions, applies the same three-model disagreement rule to both
post-development cohorts, and recomputes the 11- and 44-query break-even table.
The archived JSON replaces private filesystem roots and physical hostnames with
stable tokens; quantitative fields, host-identity equality, job ordering, and
hash references are retained.

No GPU, scheduler account, network access, third-party Python package, or ASTRA
installation is required. The snapshot validates preserved detailed result
rows; it does not rerun CUDA capture, Transformer training, Chakra lowering, or
ASTRA itself.

The Chakra/ASTRA summary replaces the private project root with
`${PROJECT_ROOT}` and per-job temporary root with `${JOB_TMP}`. Its provenance
record retains the SHA-256 of both the sealed source and redacted artifact.
Raw scheduler logs, profiler traces, binaries, physical hostnames, account
identifiers, and private filesystem paths are intentionally excluded. Compact
accounting records retain job identifiers, wall times, point-relevant totals,
and stable anonymized host equality needed to reconstruct the paper's costs and
allocation counts.

Scope of the artifact:

- H100 and the pinned evaluated software/workload families only;
- the 4/4 paired-TP pass applies only to the exact four-layer FP32,
  sequence-2048, batch-size-one, H4096/H5120, TP1-to-TP2 and TP2-to-TP4 domain;
- the comparison predictors were stored after source
  acquisition completed but before target measurements were read, and do not
  establish that one interpolation coordinate is generally superior;
- the endpoint-measurement frontier is a retrospective policy analysis over
  predictions that preceded their targets; all ten tasks favored TP4, so the
  selection count does not cover close or non-monotonic alternatives;
- fixed-resource planning results are deterministic replays, not a live
  scheduler deployment; the separate language-model study uses offline,
  isolated tool sessions rather than an autonomous production workflow;
- the boundary suite checks deterministic action routing and reason codes; it
  is not a statistical estimate of out-of-domain detection accuracy;
- replayed timing-row savings exclude the calibration rows common to both
  predictive strategies and are not a GPU-time claim;
- ASTRA representation and backend executability, not calibrated H100 timing;
- no H200, Blackwell, arbitrary-program, heterogeneous, or 4,096-GPU timing
  claim; and
- zero false admissions on the specified 72 mutations, not a universal formal
  guarantee.

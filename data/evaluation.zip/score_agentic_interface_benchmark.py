#!/usr/bin/env python3
"""Audit traces and score the frozen language-model tool-use benchmark."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


HERE = Path(__file__).resolve().parent
CORPUS = HERE / "evidence/scaletether/agentic-interface-benchmark-v1.json"
RUNS = HERE / "evidence/scaletether/agentic-interface-runs-v1"
OUTPUT = HERE / "evidence/scaletether/agentic-interface-results-v1.json"
COMMAND = re.compile(
    r"agentic_interface_tool\.py --interface (?P<interface>\S+) "
    r"--case (?P<case>\S+) (?P<command>query|measure)(?: --tp (?P<tp>[124]))?"
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trace(path: Path, interface: str, case_id: str) -> dict[str, object]:
    queries = 0
    measurements: list[int] = []
    disallowed: list[str] = []
    usage: dict[str, int] = {}
    for raw in path.read_text().splitlines():
        event = json.loads(raw)
        if event["type"] == "turn.completed":
            usage = event.get("usage", {})
        item = event.get("item", {})
        if event["type"] != "item.completed" or item.get("type") != "command_execution":
            continue
        command = item["command"]
        match = COMMAND.search(command)
        if not match:
            disallowed.append(command)
            continue
        if match["interface"] != interface or match["case"] != case_id:
            disallowed.append(command)
            continue
        if match["command"] == "query":
            queries += 1
        else:
            measurements.append(int(match["tp"]))
    return {
        "query_calls": queries,
        "measurement_calls": measurements,
        "disallowed_commands": disallowed,
        "usage": usage,
    }


def score_episode(task: dict[str, object], interface: str) -> dict[str, object]:
    case_id = str(task["case_id"])
    directory = RUNS / interface / case_id
    result = json.loads((directory / "result.json").read_text())
    observed = trace(directory / "transcript.jsonl", interface, case_id)
    measurements = observed["measurement_calls"]
    required = task["required_measurements"]
    selected = result["selected_tp"]
    decision = result["decision"]
    action = task["frozen_action"]
    query_valid = observed["query_calls"] == 1
    report_valid = sorted(result["measurements_used"]) == sorted(measurements)
    no_duplicate_measurements = len(measurements) == len(set(measurements))

    if action == "ESTIMATE":
        action_valid = (
            decision == "SELECT"
            and selected == task["certified_tp"]
            and not measurements
        )
    elif action == "MEASURE":
        action_valid = (
            decision == "SELECT"
            and selected == task["measured_optimum_tp"]
            and sorted(measurements) == sorted(required)
        )
    else:
        action_valid = decision == "STOP" and selected is None and not measurements

    protocol_valid = (
        query_valid
        and report_valid
        and no_duplicate_measurements
        and not observed["disallowed_commands"]
        and action_valid
    )
    supported = action in {"ESTIMATE", "MEASURE"}
    completed_supported = supported and decision == "SELECT"
    exact = completed_supported and selected == task["measured_optimum_tp"]
    regret = None
    if completed_supported and task["measured_us"] is not None:
        medians = task["measured_us"]
        best = min(medians.values())
        regret = (medians[str(selected)] / best - 1.0) * 100.0

    return {
        "case_id": case_id,
        "interface": interface,
        "frozen_action": action,
        "decision": decision,
        "selected_tp": selected,
        "actual_measurements": measurements,
        "reported_measurements": result["measurements_used"],
        "protocol_valid": protocol_valid,
        "completed_supported": completed_supported,
        "exact_measured_optimum": exact,
        "regret_percent": regret,
        "ignored_measure": action == "MEASURE"
        and sorted(measurements) != sorted(required),
        "ignored_unsupported": action == "UNSUPPORTED"
        and (decision != "STOP" or bool(measurements)),
        "unnecessary_measurements": len(measurements) if action != "MEASURE" else 0,
        "disallowed_command_count": len(observed["disallowed_commands"]),
        "usage": observed["usage"],
    }


def summarize(rows: list[dict[str, object]]) -> dict[str, object]:
    supported = [row for row in rows if row["frozen_action"] != "UNSUPPORTED"]
    selected = [row for row in supported if row["regret_percent"] is not None]
    return {
        "episodes": len(rows),
        "protocol_valid": sum(row["protocol_valid"] for row in rows),
        "ignored_measure": sum(row["ignored_measure"] for row in rows),
        "ignored_unsupported": sum(row["ignored_unsupported"] for row in rows),
        "unnecessary_measurements": sum(
            row["unnecessary_measurements"] for row in rows
        ),
        "measurement_calls": sum(len(row["actual_measurements"]) for row in rows),
        "supported_tasks_completed": sum(
            row["completed_supported"] for row in supported
        ),
        "exact_measured_optimum": sum(
            row["exact_measured_optimum"] for row in supported
        ),
        "maximum_regret_percent": max(row["regret_percent"] for row in selected),
        "mean_regret_percent": sum(row["regret_percent"] for row in selected)
        / len(selected),
        "disallowed_command_count": sum(
            row["disallowed_command_count"] for row in rows
        ),
        "input_tokens": sum(row["usage"].get("input_tokens", 0) for row in rows),
        "output_tokens": sum(row["usage"].get("output_tokens", 0) for row in rows),
    }


def build() -> dict[str, object]:
    corpus = json.loads(CORPUS.read_text())
    rows = [
        score_episode(task, interface)
        for interface in corpus["interfaces"]
        for task in corpus["tasks"]
    ]
    return {
        "schema": "scaletether-agentic-interface-results-v1",
        "claim": "offline-language-model-tool-use-compliance-not-live-scheduler-control",
        "model": corpus["model"],
        "model_reasoning_effort": corpus["model_reasoning_effort"],
        "benchmark_sha256": digest(CORPUS),
        "benchmark_prompt_freeze_commit": "ded4c030983d2f226f978154f28264d6580ce304",
        "schema_compatibility_commit": "89749d855db3cb4125d094cb0726a8fccf67654b",
        "transport_failures_before_model_output": 1,
        "rows": rows,
        "summary": {
            interface: summarize([row for row in rows if row["interface"] == interface])
            for interface in corpus["interfaces"]
        },
        "interpretation": (
            "Typed actions changed tool-use compliance relative to numeric-only output. "
            "The full response did not improve over action-only in this fixed three-candidate task."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    rendered = json.dumps(build(), indent=2, sort_keys=True) + "\n"
    if args.check:
        if not args.output.exists() or args.output.read_text() != rendered:
            raise SystemExit("agentic interface results are stale")
    else:
        args.output.write_text(rendered)
    payload = json.loads(rendered)
    for interface, summary in payload["summary"].items():
        print(
            f"{interface}: valid={summary['protocol_valid']}/15 "
            f"exact={summary['exact_measured_optimum']}/10 "
            f"measurements={summary['measurement_calls']}"
        )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Audit and score the preregistered untyped-prose extension v3."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
from typing import Any

from run_agentic_interface_prose_v3 import (
    CODEX_VERSION,
    CORPUS,
    MODELS,
    OUTPUT as RUNS,
    PREREG,
    PROMPTS,
    REASONING_EFFORT,
    REPETITIONS,
)


HERE = Path(__file__).resolve().parent
RESULT = HERE / "evidence/scaletether/agentic-interface-prose-v3.json"
COMMAND = re.compile(
    r"agentic_interface_prose_tool\.py --case (?P<case>\S+) "
    r"(?P<command>query|measure)(?: --tp (?P<tp>[124]))?"
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trace(path: Path, case_id: str) -> dict[str, Any]:
    queries = 0
    measurements: list[int] = []
    disallowed: list[str] = []
    usage: dict[str, int] = {}
    for raw in path.read_text().splitlines():
        event = json.loads(raw)
        if event["type"] == "turn.completed":
            usage = event.get("usage", {})
        item = event.get("item", {})
        if event["type"] != "item.completed" or item.get("type") != "command_execution":
            continue
        command = item["command"]
        match = COMMAND.search(command)
        if not match or match["case"] != case_id:
            disallowed.append(command)
        elif match["command"] == "query":
            queries += 1
        else:
            measurements.append(int(match["tp"]))
    return {
        "query_calls": queries,
        "measurement_calls": measurements,
        "disallowed_commands": disallowed,
        "usage": usage,
    }


def score_episode(
    task: dict[str, Any], model_label: str, prompt_label: str, repetition: int
) -> dict[str, Any]:
    case_id = str(task["case_id"])
    directory = RUNS / model_label / prompt_label / f"rep{repetition}" / case_id
    result = json.loads((directory / "result.json").read_text())
    metadata = json.loads((directory / "metadata.json").read_text())
    if metadata["returncode"] != 0:
        raise ValueError(f"nonzero model session: {directory}")
    observed = trace(directory / "transcript.jsonl", case_id)
    measurements = observed["measurement_calls"]
    required = task["required_measurements"]
    selected = result["selected_tp"]
    decision = result["decision"]
    action = task["frozen_action"]
    query_valid = observed["query_calls"] == 1
    report_valid = sorted(result["measurements_used"]) == sorted(measurements)
    no_duplicates = len(measurements) == len(set(measurements))

    if action == "ESTIMATE":
        action_valid = decision == "SELECT" and selected == task["certified_tp"] and not measurements
    elif action == "MEASURE":
        action_valid = (
            decision == "SELECT"
            and selected == task["measured_optimum_tp"]
            and sorted(measurements) == sorted(required)
        )
    else:
        action_valid = decision == "STOP" and selected is None and not measurements
    protocol_valid = (
        query_valid and report_valid and no_duplicates
        and not observed["disallowed_commands"] and action_valid
    )
    supported = action in {"ESTIMATE", "MEASURE"}
    completed_supported = supported and decision == "SELECT"
    exact = completed_supported and selected == task["measured_optimum_tp"]
    regret = None
    if completed_supported and task["measured_us"] is not None:
        medians = task["measured_us"]
        best = min(medians.values())
        regret = (medians[str(selected)] / best - 1.0) * 100.0
    return {
        "case_id": case_id,
        "model": MODELS[model_label],
        "model_label": model_label,
        "prompt_label": prompt_label,
        "repetition": repetition,
        "interface": "untyped-prose",
        "frozen_action": action,
        "decision": decision,
        "selected_tp": selected,
        "actual_measurements": measurements,
        "protocol_valid": protocol_valid,
        "completed_supported": completed_supported,
        "exact_measured_optimum": exact,
        "regret_percent": regret,
        "ignored_measure": action == "MEASURE" and sorted(measurements) != sorted(required),
        "ignored_unsupported": action == "UNSUPPORTED" and (decision != "STOP" or bool(measurements)),
        "unnecessary_measurements": len(measurements) if action != "MEASURE" else 0,
        "disallowed_command_count": len(observed["disallowed_commands"]),
        "usage": observed["usage"],
    }


def summarize(rows: list[dict[str, Any]]) -> dict[str, Any]:
    supported = [row for row in rows if row["frozen_action"] != "UNSUPPORTED"]
    selected = [row for row in supported if row["regret_percent"] is not None]
    return {
        "sessions": len(rows),
        "supported_sessions": len(supported),
        "protocol_valid": sum(row["protocol_valid"] for row in rows),
        "ignored_measure": sum(row["ignored_measure"] for row in rows),
        "ignored_unsupported": sum(row["ignored_unsupported"] for row in rows),
        "unnecessary_measurements": sum(row["unnecessary_measurements"] for row in rows),
        "measurement_calls": sum(len(row["actual_measurements"]) for row in rows),
        "exact_measured_optimum": sum(row["exact_measured_optimum"] for row in supported),
        "maximum_regret_percent": max((row["regret_percent"] for row in selected), default=None),
        "mean_regret_percent": (
            sum(row["regret_percent"] for row in selected) / len(selected) if selected else None
        ),
        "disallowed_command_count": sum(row["disallowed_command_count"] for row in rows),
        "input_tokens": sum(row["usage"].get("input_tokens", 0) for row in rows),
        "output_tokens": sum(row["usage"].get("output_tokens", 0) for row in rows),
    }


def build() -> dict[str, Any]:
    corpus = json.loads(CORPUS.read_text())
    rows = [
        score_episode(task, model, prompt, repetition)
        for model in MODELS
        for prompt in PROMPTS
        for repetition in REPETITIONS
        for task in corpus["tasks"]
    ]
    expected = len(MODELS) * len(PROMPTS) * len(REPETITIONS) * 15
    if len(rows) != expected:
        raise ValueError(f"expected {expected} sessions, found {len(rows)}")
    return {
        "schema": "scaletether-agentic-interface-prose-v3",
        "claim": "offline-untyped-prose-interface-follow-up",
        "benchmark_sha256": digest(CORPUS),
        "preregistration_sha256": digest(PREREG),
        "models": MODELS,
        "prompts": {label: digest(path) for label, path in PROMPTS.items()},
        "repetitions": list(REPETITIONS),
        "inference": {
            "codex_cli_version": CODEX_VERSION,
            "reasoning_effort": REASONING_EFFORT,
            "temperature": "not exposed by Codex CLI",
            "random_seed": "not exposed by Codex CLI",
            "session_mode": "fresh ephemeral sessions",
        },
        "rows": rows,
        "summary": summarize(rows),
        "by_model": {
            model: summarize([row for row in rows if row["model_label"] == model])
            for model in MODELS
        },
        "by_prompt": {
            prompt: summarize([row for row in rows if row["prompt_label"] == prompt])
            for prompt in PROMPTS
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=RESULT)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    rendered = json.dumps(build(), indent=2, sort_keys=True) + "\n"
    if args.check:
        if not args.output.exists() or args.output.read_text() != rendered:
            raise SystemExit("untyped-prose interface result is stale")
    else:
        args.output.write_text(rendered)
    row = json.loads(rendered)["summary"]
    print(
        f"untyped-prose: valid={row['protocol_valid']}/{row['sessions']} "
        f"exact={row['exact_measured_optimum']}/{row['supported_sessions']} "
        f"measurements={row['measurement_calls']}"
    )


if __name__ == "__main__":
    main()

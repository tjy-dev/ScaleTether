#!/usr/bin/env python3
"""Run frozen agentic-interface episodes and retain complete Codex traces."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path


HERE = Path(__file__).resolve().parent
CORPUS = HERE / "evidence/scaletether/agentic-interface-benchmark-v1.json"
PROMPT = HERE / "agentic_interface_prompt.txt"
SCHEMA = HERE / "agentic_interface_response.schema.json"
TOOL = HERE / "agentic_interface_tool.py"
OUTPUT = HERE / "evidence/scaletether/agentic-interface-runs-v1"
EMPTY_CWD = Path("/tmp/agentic-hpc-empty")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invocation(interface: str, case_id: str) -> tuple[list[str], str]:
    prompt = PROMPT.read_text().format(
        tool_command=TOOL,
        interface=interface,
        case_id=case_id,
    )
    command = [
        "codex",
        "exec",
        "-",
        "--ephemeral",
        "--ignore-user-config",
        "--ignore-rules",
        "--skip-git-repo-check",
        "-C",
        str(EMPTY_CWD),
        "-s",
        "read-only",
        "-m",
        "gpt-5.6-sol",
        "-c",
        'model_reasoning_effort="medium"',
        "--output-schema",
        str(SCHEMA),
        "--json",
    ]
    return command, prompt


def run_one(interface: str, case_id: str) -> tuple[str, str, int]:
    target = OUTPUT / interface / case_id
    target.mkdir(parents=True, exist_ok=True)
    result_path = target / "result.json"
    transcript_path = target / "transcript.jsonl"
    stderr_path = target / "stderr.txt"
    metadata_path = target / "metadata.json"
    metadata = {
        "case_id": case_id,
        "interface": interface,
        "corpus_sha256": digest(CORPUS),
        "prompt_sha256": digest(PROMPT),
        "response_schema_sha256": digest(SCHEMA),
        "tool_sha256": digest(TOOL),
    }
    if result_path.exists() and transcript_path.exists():
        if not metadata_path.exists():
            metadata_path.write_text(
                json.dumps(metadata | {"returncode": 0}, indent=2, sort_keys=True)
                + "\n"
            )
        return interface, case_id, 0

    command, prompt = invocation(interface, case_id)
    command.extend(["-o", str(result_path)])
    with transcript_path.open("w") as stdout, stderr_path.open("w") as stderr:
        completed = subprocess.run(
            command,
            input=prompt,
            text=True,
            stdout=stdout,
            stderr=stderr,
            check=False,
        )
    metadata_path.write_text(
        json.dumps(
            metadata | {"returncode": completed.returncode}, indent=2, sort_keys=True
        )
        + "\n"
    )
    return interface, case_id, completed.returncode


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=4)
    args = parser.parse_args()
    corpus = json.loads(CORPUS.read_text())
    EMPTY_CWD.mkdir(parents=True, exist_ok=True)
    jobs = [
        (interface, task["case_id"])
        for interface in corpus["interfaces"]
        for task in corpus["tasks"]
    ]
    failures = []
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        futures = {executor.submit(run_one, *job): job for job in jobs}
        for future in as_completed(futures):
            interface, case_id, returncode = future.result()
            print(f"{interface}/{case_id}: exit={returncode}", flush=True)
            if returncode:
                failures.append((interface, case_id, returncode))
    if failures:
        raise SystemExit(f"failed episodes: {failures}")
    print(f"agentic_interface_episodes={len(jobs)}")


if __name__ == "__main__":
    main()

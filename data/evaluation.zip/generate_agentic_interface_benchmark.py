#!/usr/bin/env python3
"""Generate the frozen agentic-interface benchmark without model output."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
V8 = HERE / "evidence/scaletether/fixed-resource-v8-paper-package/primary-cases.csv"
BOUNDARY = HERE / "evidence/scaletether/planner-boundary-suite.json"
OUTPUT = HERE / "evidence/scaletether/agentic-interface-benchmark-v1.json"
SEED = "20260810-agentic-interface-v1"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rank_key(case_id: str) -> str:
    return hashlib.sha256(f"{SEED}:{case_id}".encode()).hexdigest()


def load_v8() -> list[dict[str, object]]:
    with V8.open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    tasks = []
    for row in rows:
        medians = {str(k): float(v) for k, v in json.loads(row["medians_us"]).items()}
        requested = [int(tp) for tp in json.loads(row["requested_tps"])]
        tasks.append(
            {
                "case_id": f"v8-{int(row['task_id']):03d}",
                "source": "V8",
                "hidden_size": int(row["hidden_size"]),
                "sequence_length": int(row["sequence_length"]),
                "candidates": [1, 2, 4],
                "frozen_action": row["action"],
                "unconditional_tp": int(row["blind_log_selected_tp"]),
                "certified_tp": int(row["selected_tp"]) if row["selected_tp"] else None,
                "required_measurements": requested,
                "reason_code": (
                    "models-unanimous"
                    if row["action"] == "ESTIMATE"
                    else "model-disagreement"
                ),
                "measured_us": medians,
                "measured_optimum_tp": int(row["physically_fastest_tp"]),
                "unconditional_regret_percent": float(row["blind_log_regret_percent"]),
            }
        )
    return tasks


def load_boundary() -> list[dict[str, object]]:
    payload = json.loads(BOUNDARY.read_text())
    tasks = []
    for index, row in enumerate(payload["rows"], start=1):
        if row["expected_action"] != "UNSUPPORTED":
            continue
        tasks.append(
            {
                "case_id": f"boundary-{index:02d}",
                "source": "boundary-suite",
                "query": row["query"],
                "candidates": [1, 2, 4],
                "frozen_action": "UNSUPPORTED",
                "unconditional_tp": 4,
                "certified_tp": None,
                "required_measurements": [],
                "reason_code": row["reason_code"],
                "measured_us": None,
                "measured_optimum_tp": None,
                "unconditional_regret_percent": None,
            }
        )
    return tasks


def choose(tasks: list[dict[str, object]]) -> list[dict[str, object]]:
    estimates = [task for task in tasks if task["frozen_action"] == "ESTIMATE"]
    measures = [task for task in tasks if task["frozen_action"] == "MEASURE"]
    harmful = [task for task in measures if task["unconditional_regret_percent"] > 1.0]
    conservative = [
        task for task in measures if task["unconditional_regret_percent"] <= 1.0
    ]
    unsupported = load_boundary()

    def take(rows: list[dict[str, object]], count: int) -> list[dict[str, object]]:
        return sorted(rows, key=lambda row: rank_key(str(row["case_id"])))[:count]

    selected = (
        take(estimates, 5)
        + take(harmful, 3)
        + take(conservative, 2)
        + take(unsupported, 5)
    )
    return sorted(selected, key=lambda row: rank_key(str(row["case_id"])))


def build() -> dict[str, object]:
    selected = choose(load_v8())
    return {
        "schema": "scaletether-agentic-interface-benchmark-v1",
        "status": "frozen-before-language-model-execution",
        "seed": SEED,
        "selection": {
            "ESTIMATE": 5,
            "MEASURE_harmful_unconditional": 3,
            "MEASURE_conservative": 2,
            "UNSUPPORTED": 5,
        },
        "interfaces": ["numeric-only", "action-only", "full"],
        "model": "gpt-5.6-sol",
        "model_reasoning_effort": "medium",
        "sources": {
            str(V8.relative_to(ROOT)): sha256(V8),
            str(BOUNDARY.relative_to(ROOT)): sha256(BOUNDARY),
        },
        "tasks": selected,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--check", action="store_true")
    args = parser.parse_args()
    rendered = json.dumps(build(), indent=2, sort_keys=True) + "\n"
    if args.check:
        if not args.output.exists() or args.output.read_text() != rendered:
            raise SystemExit("agentic interface benchmark is stale")
    else:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered)
    print(
        f"agentic_interface_tasks={len(json.loads(rendered)['tasks'])} check={args.check}"
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Independently recompute the compact reviewer artifact's paper metrics."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
DEFAULT_EVIDENCE = ROOT / "artifact" / "evidence"
PAIRED_TP_EVIDENCE = ROOT / "evidence" / "scaletether"
TARGETS = ("TP-A", "TP-B", "DP-A", "DP-B", "PP-A", "PP-B")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def close(
    actual: float, expected: float, message: str, tolerance: float = 1e-12
) -> None:
    if not math.isclose(actual, expected, rel_tol=0.0, abs_tol=tolerance):
        raise ValueError(f"{message}: {actual} != {expected}")


def load(root: Path, name: str) -> dict[str, Any]:
    return json.loads((root / name).read_text(encoding="utf-8"))


def validate_planner_boundary(root: Path) -> dict[str, int]:
    document = load(root, "planner-boundary-suite.json")
    require(
        document["schema"] == "scaletether-planner-boundary-suite-v1"
        and document["implementation"] == "scaletether.planner_contract.decide"
        and document["case_count"] == 9
        and document["passed_case_count"] == 9,
        "planner boundary suite identity or totals changed",
    )
    counts = {"ESTIMATE": 0, "MEASURE": 0, "UNSUPPORTED": 0}
    for row in document["rows"]:
        require(
            row["passed"]
            and row["expected_action"] == row["returned_action"]
            and row["reason_code"],
            f"planner boundary decision changed: {row.get('query')}",
        )
        counts[row["returned_action"]] += 1
    require(
        counts == {"ESTIMATE": 1, "MEASURE": 2, "UNSUPPORTED": 6},
        "planner boundary action coverage changed",
    )
    return counts


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_measurement_frontier(root: Path) -> None:
    document = load(root, "megatron-measurement-frontier.json")
    require(
        document["schema"] == "scaletether-megatron-measurement-frontier-v1"
        and len(document["tasks"]) == 10,
        "Megatron measurement-frontier identity changed",
    )
    sequential = document["summary"]["sequential"]
    recursive = document["summary"]["recursive"]
    require(
        sequential["endpoint_measurements_per_task"] == 2
        and sequential["correct_fastest_selections"] == 10
        and recursive["endpoint_measurements_per_task"] == 1
        and recursive["correct_fastest_selections"] == 10,
        "Megatron measurement-frontier result changed",
    )


def validate_paired_tp(root: Path) -> dict[str, float | int]:
    primary = load(root, "paired-tp-v8.json")
    baselines = load(root, "paired-tp-v8-baselines.json")
    require(
        primary["schema"] == "scaletether-paper-paired-tp-v8-primary-v1"
        and primary["status"] == "passed",
        "paired-TP primary identity or status changed",
    )
    require(
        primary["source"]["primary_score_file_sha256"]
        == "fc50639ddbe32973b0361554e086087643b445a04c9c8363dcd08d2302700bf6"
        and primary["source"]["matrix_sha256"]
        == "38862eb82456e68576f73907ddfcaf40f37da34d81436ffcebecf7065f882a6f",
        "paired-TP frozen source identity changed",
    )
    rows = primary["rows"]
    require(
        [(row["hidden_size"], row["source_tp"], row["target_tp"]) for row in rows]
        == [
            (4096, 1, 2),
            (4096, 2, 4),
            (5120, 1, 2),
            (5120, 2, 4),
        ]
        and primary["protocol"]["ratio_predictions_frozen_before_target_acquisition"]
        is True
        and primary["protocol"]["absolute_prediction_stored_after_source_before_target"]
        is True
        and primary["protocol"]["distinct_physical_host_count"] == 3
        and primary["protocol"]["anonymous_host_outer_multiplicities"] == [2, 2, 1]
        and primary["protocol"]["simultaneity_claimed"] is False,
        "paired-TP target grid changed",
    )
    median_errors: list[float] = []
    outer_count = 0
    for row in rows:
        observations = [float(run["observed_ratio"]) for run in row["runs"]]
        observed_median = statistics.median(observations)
        errors = [float(run["absolute_target_time_ape_percent"]) for run in row["runs"]]
        deviations = [
            100 * abs(float(observed) - observed_median) / observed_median
            for observed in observations
        ]
        median_error = statistics.median(errors)
        median_errors.append(median_error)
        within = sum(error <= 10 for error in errors)
        outer_count += within
        close(
            median_error,
            float(row["median_absolute_target_time_ape_percent"]),
            "paired-TP median outer error",
            5e-6,
        )
        close(
            max(deviations),
            float(row["maximum_observed_ratio_deviation_percent"]),
            "paired-TP maximum outer deviation",
            5e-6,
        )
        require(
            within == row["runs_within_declared_error_gate"] == 5
            and row["status"] == "passed",
            "paired-TP row gate changed",
        )
    close(
        statistics.mean(median_errors),
        1.4245533346227024,
        "paired-TP mean error",
        5e-6,
    )
    close(
        max(median_errors),
        2.4280448995062764,
        "paired-TP worst error",
        5e-6,
    )
    require(
        primary["aggregate"]["passed_transition_count"] == 4
        and primary["aggregate"]["transition_count"] == 4
        and outer_count == primary["aggregate"]["run_count"] == 20,
        "paired-TP aggregate gate changed",
    )
    require(
        baselines["schema"] == "scaletether-paper-paired-tp-v8-baselines-v1"
        and baselines["status"] == "secondary-target-blind-comparison"
        and baselines["target_blind"] is True
        and baselines["absolute_and_ratio_ape_are_identical"] is True
        and baselines["source"]["comparison_file_sha256"]
        == "34e9508b509e82169775ec4d599932d0a5dfc6f7813d707334e3d04a860b0df3"
        and [row["method"] for row in baselines["rows"]]
        == [
            "ScaleTether log-hidden interpolation",
            "Raw-hidden interpolation",
            "Nearest anchor",
            "Ideal TP scaling",
            "No speedup",
        ],
        "paired-TP secondary comparison changed",
    )
    require(
        baselines["rows"][0]["mean_transition_median_ape_percent"]
        < baselines["rows"][1]["mean_transition_median_ape_percent"]
        and baselines["rows"][0]["maximum_transition_median_ape_percent"]
        < baselines["rows"][1]["maximum_transition_median_ape_percent"]
        and baselines["rows"][0]["transitions_won"] == 2,
        "paired-TP baseline comparison changed",
    )
    return {
        "contrasts": len(rows),
        "outer_observations": outer_count,
        "mean_error_percent": statistics.mean(median_errors),
        "worst_error_percent": max(median_errors),
    }


def policy_observations(
    workload: dict[str, Any],
) -> tuple[list[str], dict[str, float], dict[str, float]]:
    policies = []
    predicted = {}
    observed = {}
    for row in workload["policies"]:
        key = "default" if row["max_ctas"] is None else str(row["max_ctas"])
        policies.append(key)
        predicted[key] = float(row["predicted_step_us"])
        observed[key] = float(row["observed_step_us"])
    return policies, predicted, observed


def workload_metrics(
    policies: list[str], predicted: dict[str, float], observed: dict[str, float]
) -> dict[str, Any]:
    selected = min(policies, key=lambda key: (predicted[key], policies.index(key)))
    oracle = min(policies, key=lambda key: (observed[key], policies.index(key)))
    decision_error = max(
        0.0,
        *(
            math.log(observed[selected] / observed[alternative])
            - math.log(predicted[selected] / predicted[alternative])
            for alternative in policies
            if alternative != selected
        ),
    )
    ranking = sorted(policies, key=lambda key: (predicted[key], policies.index(key)))
    return {
        "apes": [
            abs(predicted[key] - observed[key]) / observed[key] for key in policies
        ],
        "selected": selected,
        "oracle": oracle,
        "regret": observed[selected] / observed[oracle] - 1.0,
        "decision_error": decision_error,
        "predicted_log_margin": math.log(predicted[ranking[1]] / predicted[ranking[0]]),
    }


def validate_v7(root: Path) -> dict[str, Any]:
    table = load(root, "v7-timing-table.json")
    aggregate = load(root, "transformer-v7-timing-aggregate.json")
    summary = load(root, "transformer-v7-postprocess-summary.json")
    adversarial = load(root, "transformer-v7-adversarial-score.json")
    rows = table["rows"]
    require(tuple(row["target"] for row in rows) == TARGETS, "v7 target order changed")
    calculations = {
        "median_iteration_ape_percent": statistics.median(
            row["iteration_ape_percent"] for row in rows
        ),
        "median_phase_mape_percent": statistics.median(
            row["phase_mape_percent"] for row in rows
        ),
        "median_overlap_error_percentage_points": statistics.median(
            row["overlap_error_percentage_points"] for row in rows
        ),
    }
    for name, value in calculations.items():
        close(value, float(table["aggregate"][name]), name, 5e-5)
    close(
        calculations["median_iteration_ape_percent"],
        100 * aggregate["medians"]["iteration_absolute_error_fraction"],
        "v7 aggregate iteration",
    )
    close(
        calculations["median_phase_mape_percent"],
        100 * aggregate["medians"]["phase_mape"],
        "v7 aggregate phase",
    )
    close(
        calculations["median_overlap_error_percentage_points"],
        aggregate["medians"]["overlap_absolute_error_percentage_points"],
        "v7 aggregate overlap",
    )
    require(
        summary["structural_pass_count"] == summary["structural_required"] == 6,
        "v7 structural gate changed",
    )
    require(
        adversarial["case_count"] == len(adversarial["cases"]) == 72,
        "adversarial case count changed",
    )
    require(
        not any(case["admitted"] for case in adversarial["cases"]),
        "invalid mutation was admitted",
    )
    require(
        not any(case.get("validator_exception") for case in adversarial["cases"])
        and all(
            "validator-exception" not in case["rejection_failures"]
            for case in adversarial["cases"]
        )
        and sum(
            "invalid-graph" in case["rejection_failures"]
            for case in adversarial["cases"]
        )
        == 2,
        "malformed graph mutations must produce typed invalid-graph rejections",
    )
    require(
        adversarial["false_admission"]
        == {
            "count": 0,
            "rate": 0.0,
            "trials": 72,
            "clopper_pearson_95": [0.0, 0.049944083705854625],
        },
        "false-admission summary changed",
    )

    accounting = load(root, "transformer-v7-acquisition-accounting.json")
    scheduler = accounting["scheduler_allocated_gpu_seconds"]
    close(
        scheduler["direct_measure_every_target"]
        - scheduler["generated_with_fallbacks"],
        scheduler["savings"],
        "scheduler savings",
    )
    close(
        scheduler["savings"] / scheduler["direct_measure_every_target"],
        scheduler["savings_fraction"],
        "scheduler savings fraction",
    )

    replay = load(root, "transformer-v7-chakra-astra-summary-redacted.json")
    require(
        replay["claim"]
        == "representation-and-backend-executability-only-not-timing-calibration",
        "ASTRA claim boundary changed",
    )
    require(
        replay["row_count"] == replay["expected_row_count"] == 12,
        "ASTRA replay row count changed",
    )
    require(
        {(row["target_id"], row["kind"]) for row in replay["rows"]}
        == {(target, kind) for target in TARGETS for kind in ("generated", "physical")},
        "ASTRA replay target/kind grid changed",
    )
    for row in replay["rows"]:
        astra = row["astra"]
        semantic = row["chakra"]["semantic_validation"]
        require(
            astra["completion_status"] == "complete"
            and astra["exit_status"] == 0
            and not astra["timed_out"],
            "ASTRA execution did not complete",
        )
        require(astra["expected_rank_count"] == 4, "ASTRA rank count changed")
        require(
            semantic["status"] == "exact-protobuf-roundtrip"
            and semantic["rank_files_validated"] == 4,
            "Chakra semantic round trip changed",
        )
    return calculations | {
        "false_admissions": 0,
        "replay_rows": 12,
        "scheduler_savings_fraction": scheduler["savings_fraction"],
    }


def validate_16h100(root: Path) -> dict[str, float | int]:
    result = load(root, "policy-16h100-validation.json")
    require(
        result["schema"] == "scaletether-held-out-policy-validation-v3",
        "16-H100 schema changed",
    )
    calibration: dict[str, list[float]] = {}
    for workload in result["calibration_workloads"]:
        policies, predicted, observed = policy_observations(workload)
        require(
            policies == ["default", "4", "8", "16", "32"],
            "16-H100 policy order changed",
        )
        metric = workload_metrics(policies, predicted, observed)
        stratum = (
            "message_bytes_lt_33554432"
            if workload["message_bytes"] < 32 * 1024 * 1024
            else "message_bytes_ge_33554432"
        )
        calibration.setdefault(stratum, []).append(metric["decision_error"])
    require(
        sorted(len(values) for values in calibration.values()) == [6, 6],
        "16-H100 calibration strata changed",
    )
    quantiles = {name: max(values) for name, values in calibration.items()}

    apes: list[float] = []
    regrets: list[float] = []
    covered: list[bool] = []
    retained: list[bool] = []
    top1: list[bool] = []
    violations = 0
    for workload in result["held_out_workloads"]:
        policies, predicted, observed = policy_observations(workload)
        metric = workload_metrics(policies, predicted, observed)
        name = (
            "message_bytes_lt_33554432"
            if workload["message_bytes"] < 32 * 1024 * 1024
            else "message_bytes_ge_33554432"
        )
        bound = quantiles[name]
        certified = all(
            math.log(predicted[metric["selected"]] / predicted[alternative]) + bound
            <= math.log1p(0.01)
            for alternative in policies
            if alternative != metric["selected"]
        )
        apes.extend(metric["apes"])
        regrets.append(metric["regret"])
        covered.append(metric["decision_error"] <= bound + 1e-12)
        retained.append(certified)
        top1.append(metric["selected"] == metric["oracle"])
        violations += int(certified and metric["regret"] > 0.01 + 1e-12)
    metrics = {
        "always_predict_maximum_regret": max(regrets),
        "candidate_policies": 5,
        "decisions": len(regrets),
        "median_point_ape": statistics.median(apes),
        "maximum_point_ape": max(apes),
        "coverage": sum(covered) / len(covered),
        "retention": sum(retained) / len(retained),
        "maximum_emitted_regret": max(
            regret for regret, keep in zip(regrets, retained) if keep
        ),
        "top1": sum(top1) / len(top1),
        "retained_decisions": sum(retained),
    }
    published = result["metrics"]
    for actual, expected, label in (
        (
            metrics["median_point_ape"],
            published["median_policy_message_ape"],
            "16-H100 median APE",
        ),
        (
            metrics["maximum_point_ape"],
            published["maximum_policy_message_ape"],
            "16-H100 maximum APE",
        ),
        (
            metrics["coverage"],
            published["held_out_decision_error_coverage"],
            "16-H100 coverage",
        ),
        (
            metrics["retention"],
            published["held_out_decision_retained_fraction"],
            "16-H100 retention",
        ),
        (
            metrics["maximum_emitted_regret"],
            published["maximum_selected_policy_regret"],
            "16-H100 regret",
        ),
        (metrics["top1"], published["top1_accuracy_descriptive"], "16-H100 top1"),
    ):
        close(actual, expected, label)
    require(
        violations == published["held_out_certified_regret_violation_count"] == 0,
        "16-H100 regret violation changed",
    )
    return metrics


def validate_tp_a_followup(root: Path) -> dict[str, float]:
    result = load(root, "tp-a-followup.json")
    require(
        result["schema"] == "scaletether-paper-transformer-tp-a-followup-v1",
        "TP-A follow-up schema changed",
    )
    require(
        result["status"] == "passed-amended-prospective-target-validation",
        "TP-A follow-up status changed",
    )
    followup = result["followup"]
    require(
        followup["source_launch_count"] == 3
        and followup["target_launch_count"] == 3
        and len(followup["source_launch_scoring_medians_us"]) == 3
        and len(followup["target_launch_scoring_medians_us"]) == 3,
        "TP-A follow-up launch count changed",
    )
    require(
        followup["prediction_frozen_before_target"] is True,
        "TP-A follow-up prediction was not frozen",
    )
    require(
        followup["all_source_and_target_launch_gates_passed"] is True,
        "TP-A follow-up gate result changed",
    )
    predicted = float(followup["predicted_target_iteration_us"])
    observed = float(followup["certified_target_iteration_us"])
    ape = 100.0 * abs(predicted - observed) / observed
    close(
        ape,
        float(followup["absolute_percentage_error_percent"]),
        "TP-A follow-up APE",
        5e-10,
    )
    require(
        ape <= float(followup["threshold_percent"]),
        "TP-A follow-up exceeds its frozen threshold",
    )
    return {"ape_percent": ape}


def validate_one_node(root: Path) -> dict[str, float | int]:
    result = load(root, "policy-one-node-validation.json")
    require(
        result["schema"] == "scaletether-h100-matrix-heldout-result-v4",
        "one-node schema changed",
    )
    apes: list[float] = []
    regrets: list[float] = []
    covered: list[bool] = []
    retained: list[bool] = []
    top1: list[bool] = []
    violations = 0
    domain_coverage: dict[tuple[str, str], list[bool]] = {}
    for row in result["workloads"]:
        policies = ["default", "8", "16"]
        predicted = {key: float(row["predicted_ms"][key]) for key in policies}
        observed = {key: float(row["observed_ms"][key]) for key in policies}
        metric = workload_metrics(policies, predicted, observed)
        bound = float(row["decision_error_bound"])
        certified = bound - metric["predicted_log_margin"] <= math.log1p(0.01)
        is_covered = metric["decision_error"] <= bound + 1e-15
        require(
            metric["selected"] == row["selected_policy"]
            and metric["oracle"] == row["oracle_policy"],
            "one-node policy identity changed",
        )
        close(metric["regret"], row["selected_regret"], "one-node row regret")
        close(
            metric["decision_error"],
            row["decision_error"],
            "one-node row decision error",
        )
        require(
            certified == row["certified"] and is_covered == row["covered"],
            "one-node selective decision changed",
        )
        apes.extend(metric["apes"])
        regrets.append(metric["regret"])
        covered.append(is_covered)
        retained.append(certified)
        top1.append(metric["selected"] == metric["oracle"])
        violations += int(certified and metric["regret"] > 0.01 + 1e-15)
        domain_coverage.setdefault(
            (row["compute_kernel"], row["collective"]), []
        ).append(is_covered)
    metrics = {
        "always_predict_maximum_regret": max(regrets),
        "candidate_policies": 3,
        "decisions": len(regrets),
        "median_point_ape": statistics.median(apes),
        "maximum_point_ape": max(apes),
        "coverage": sum(covered) / len(covered),
        "retention": sum(retained) / len(retained),
        "maximum_emitted_regret": max(
            regret for regret, keep in zip(regrets, retained) if keep
        ),
        "top1": sum(top1) / len(top1),
        "retained_decisions": sum(retained),
        "minimum_domain_coverage": min(
            sum(values) / len(values) for values in domain_coverage.values()
        ),
    }
    published = result["metrics"]
    for actual, expected, label in (
        (
            metrics["median_point_ape"],
            published["policy_ape"]["median"],
            "one-node median APE",
        ),
        (
            metrics["maximum_point_ape"],
            published["policy_ape"]["maximum"],
            "one-node maximum APE",
        ),
        (
            metrics["coverage"],
            published["decision_error_coverage"],
            "one-node coverage",
        ),
        (metrics["retention"], published["certified_retention"], "one-node retention"),
        (
            metrics["maximum_emitted_regret"],
            published["maximum_recommended_policy_regret"],
            "one-node regret",
        ),
        (
            metrics["top1"],
            published["descriptive_exact_top1_accuracy"],
            "one-node top1",
        ),
        (
            metrics["minimum_domain_coverage"],
            published["minimum_domain_coverage"],
            "one-node minimum domain coverage",
        ),
    ):
        close(actual, expected, label)
    require(
        violations == published["certified_regret_violations"] == 0,
        "one-node regret violation changed",
    )
    return metrics


def validate_table(
    root: Path,
    multi: dict[str, float | int],
    one: dict[str, float | int],
) -> None:
    table = load(root, "policy-table.json")["studies"]
    require(
        [row["label"] for row in table] == ["16 H100", "One node"],
        "paper policy table order changed",
    )
    for row, metrics, heldout_rows in ((table[0], multi, 300), (table[1], one, 960)):
        require(row["heldout_rows"] == heldout_rows, "paper policy row count changed")
        for actual, key, label in (
            (
                100 * metrics["median_point_ape"],
                "median_point_ape_percent",
                "median APE",
            ),
            (
                100 * metrics["maximum_point_ape"],
                "maximum_point_ape_percent",
                "maximum APE",
            ),
            (100 * metrics["coverage"], "decision_error_coverage_percent", "coverage"),
            (
                100 * metrics["retention"],
                "recommendation_retention_percent",
                "retention",
            ),
            (
                100 * metrics["maximum_emitted_regret"],
                "maximum_emitted_regret_percent",
                "regret",
            ),
        ):
            close(actual, row[key], f"paper policy {row['label']} {label}", 5e-4)
        require(
            row["emitted_recommendations_above_one_percent_regret"] == 0,
            "paper policy violation count changed",
        )


def validate_agent_loop(
    root: Path,
    multi: dict[str, float | int],
    one: dict[str, float | int],
) -> dict[str, int]:
    replay = load(root, "agent-loop-replay.json")
    require(
        replay["schema"] == "scaletether-agent-loop-replay-v1",
        "agent-loop replay schema changed",
    )
    require(
        replay["claim"]
        == "deterministic-selective-planning-replay-not-agent-intelligence-evaluation",
        "agent-loop claim boundary changed",
    )
    require(
        "not a live autonomous-agent experiment" in replay["interpretation"],
        "agent-loop replay interpretation changed",
    )
    policy_rows = {
        row["label"]: row for row in load(root, "policy-table.json")["studies"]
    }
    expected_studies = (("16 H100", multi), ("One node", one))
    require(
        [study["label"] for study in replay["studies"]]
        == [label for label, _ in expected_studies],
        "agent-loop study order changed",
    )
    summary: dict[str, int] = {}
    for study, (label, metrics) in zip(replay["studies"], expected_studies):
        decisions = int(metrics["decisions"])
        candidate_policies = int(metrics["candidate_policies"])
        retained = int(metrics["retained_decisions"])
        requests = decisions - retained
        heldout_rows = int(policy_rows[label]["heldout_rows"])
        denominator = decisions * candidate_policies
        require(
            heldout_rows % denominator == 0,
            f"{label} held-out row grid is not rectangular",
        )
        repetitions = heldout_rows // denominator
        requested_rows = requests * candidate_policies * repetitions
        avoided_rows = heldout_rows - requested_rows
        expected = {
            "decisions": decisions,
            "candidate_policies_per_decision": candidate_policies,
            "repetitions_per_policy": repetitions,
            "heldout_timing_rows": heldout_rows,
        }
        for key, value in expected.items():
            require(study[key] == value, f"{label} agent-loop {key} changed")
        always_measure = study["always_measure"]
        require(
            always_measure
            == {
                "heldout_timing_rows_acquired": heldout_rows,
                "maximum_final_regret_fraction": 0.0,
                "measurement_requests": decisions,
                "recommendations_without_measurement": 0,
            },
            f"{label} always-measure replay changed",
        )
        always_predict = study["always_predict"]
        require(
            always_predict["heldout_timing_rows_acquired"] == 0
            and always_predict["measurement_requests"] == 0
            and always_predict["recommendations_without_measurement"] == decisions,
            f"{label} always-predict replay counts changed",
        )
        close(
            always_predict["maximum_final_regret_fraction"],
            float(metrics["always_predict_maximum_regret"]),
            f"{label} always-predict regret",
        )
        selective = study["selective_request"]
        require(
            selective["recommendations_without_measurement"] == retained
            and selective["measurement_requests"] == requests
            and selective["heldout_timing_rows_acquired"] == requested_rows
            and selective["heldout_timing_rows_avoided"] == avoided_rows,
            f"{label} selective-request replay counts changed",
        )
        close(
            selective["heldout_timing_rows_avoided_fraction"],
            avoided_rows / heldout_rows,
            f"{label} selective-request avoided fraction",
        )
        close(
            selective["maximum_final_regret_fraction"],
            float(metrics["maximum_emitted_regret"]),
            f"{label} selective-request regret",
        )
        key = "16h100" if label == "16 H100" else "one_node"
        summary[f"{key}_acquired_rows"] = requested_rows
        summary[f"{key}_heldout_rows"] = heldout_rows
    return summary


def validate_planner_interface(root: Path) -> None:
    study = load(root, "planner-interface-study.json")
    require(
        study["schema"] == "scaletether-planner-interface-study-v2"
        and study["claim"]
        == "deterministic-planner-interface-replay-not-llm-behavior-evaluation"
        and study["decision_interface"] == ["ESTIMATE", "MEASURE", "UNSUPPORTED"]
        and study["unsupported_scope"]["queries_in_frozen_corpus"] == 0,
        "planner-interface claim boundary changed",
    )
    expected = (
        ("16 H100", 12, 300, 1.0, 1, 25, 7, 8, 0.003226108974960118),
        ("One node", 64, 960, 63 / 64, 24, 360, 57, 61, 0.0016691147015623908),
    )
    for row, values in zip(study["studies"], expected):
        (
            label,
            decisions,
            heldout,
            empirical_coverage,
            uncertified,
            acquired,
            blind_best,
            aware_best,
            regret,
        ) = values
        blind = row["strategies"]["blind-always-predict"]
        aware = row["strategies"]["status-aware-selective-request"]
        measured = row["strategies"]["always-measure"]
        require(
            row["label"] == label
            and row["decisions"] == decisions
            and row["heldout_timing_rows"] == heldout
            and row["requested_decision_error_coverage"] == 0.8
            and row["empirical_decision_error_coverage"] == empirical_coverage
            and blind["uncertified_estimates"] == uncertified
            and blind["exact_best_recommendations"] == blind_best
            and aware["uncertified_estimates"] == 0
            and aware["heldout_timing_rows_acquired"] == acquired
            and aware["exact_best_recommendations"] == aware_best
            and abs(aware["maximum_final_regret_fraction"] - regret) < 1e-15
            and measured["heldout_timing_rows_acquired"] == heldout
            and measured["maximum_final_regret_fraction"] == 0.0,
            f"planner-interface row changed: {label}",
        )


def validate_scale_4096(root: Path) -> None:
    scale = load(root, "scale-4096-evidence.json")
    export = scale["export_only_gate"]
    backend = scale["exact_backend_gate"]["backend"]
    end_to_end = scale["exact_backend_gate"]["end_to_end"]
    require(
        scale["schema"] == "scaletether-paper-scale-evidence-v1"
        and export["status"] == "pass"
        and export["rank_files"] == 4096
        and export["total_nodes"] == 2_035_712
        and export["dp_collective_nodes"] == 73_728
        and export["export_wall_seconds"] == 19.2
        and export["export_peak_rss_kib"] == 41_784,
        "4,096-rank export evidence changed",
    )
    require(
        backend["astra_sim_commit"] == "518bd513ae110428cd62eb60efc0f3993fd53c70"
        and backend["change"]
        == "rank-local communicator parsing and instantiation only"
        and backend["eight_rank_metrics_match_unmodified_backend"] == "bit-exact"
        and backend["completion_status"] == "complete"
        and backend["exit_status"] == 0
        and backend["complete_rank_metrics"] == 4096
        and abs(backend["wall_seconds"] - 53.751796962693334) < 1e-12
        and end_to_end["wall_seconds"] == 72.68
        and end_to_end["peak_rss_kib"] == 8_079_744
        and "calibrated 4096-GPU timing accuracy"
        in scale["claim_boundary"]["not_established"],
        "4,096-rank backend evidence or claim boundary changed",
    )


def validate_study_chronology(root: Path) -> None:
    chronology = load(root, "fixed-resource-chronology-v1.json")
    require(
        chronology["schema"] == "scaletether-fixed-resource-chronology-v1",
        "fixed-resource chronology schema changed",
    )
    phases = chronology["phases"]
    require(
        [row["phase"] for row in phases] == ["V4", "V5", "V6", "V7", "V8"]
        and [row["queries"] for row in phases] == [8, 4, 6, 18, 80]
        and [row["used_to_change_predictor_or_gate"] for row in phases]
        == [False, True, False, False, False]
        and phases[1]["included_in_primary_v8_result"] is False
        and phases[4]["included_in_primary_v8_result"] is True
        and chronology["claim_boundary"]["missing_local_freeze_documents"]
        == ["V5", "V6", "V7"],
        "fixed-resource chronology or disclosure changed",
    )
    require(
        all(row["predictor"].startswith("unchanged V4") for row in phases[1:])
        and all("three-model unanimity" in row["gate"] for row in phases[2:]),
        "post-development predictor or gate identity changed",
    )


def validate_structural_campaign_identities(root: Path) -> None:
    document = load(root, "structural-campaign-identities-v1.json")
    campaigns = document["campaigns"]
    require(
        document["schema"] == "scaletether-structural-campaign-identities-v1"
        and document["headline_structural_campaign"] == "S-V7"
        and document["headline_generated_graph_pairs"] == 6
        and [row["id"] for row in campaigns]
        == ["S-V7-A", "S-V7-B", "L-V16-A", "L-V16-B", "MLP-V4"]
        and sum(row["headline_graph_pairs"] for row in campaigns) == 6,
        "structural campaign identity or headline count changed",
    )
    require(
        campaigns[0]["source"]["sequence_length"] == 752
        and campaigns[1]["source"]["sequence_length"] == 784
        and campaigns[2]["source"]["sequence_length"] == 1024
        and campaigns[3]["source"]["sequence_length"] == 2048
        and "5/6" in document["claim_boundaries"]["large_campaign"]
        and "unsupported" in document["claim_boundaries"]["pipeline_parallel"],
        "structural campaign dimensions or claim boundary changed",
    )


def validate_v8_planner_loop(root: Path) -> None:
    document = load(root, "v8-planner-loop-replay-v1.json")
    summary = document["summary"]
    require(
        document["schema"] == "scaletether-v8-scripted-planner-loop-replay-v1"
        and document["claim"]
        == "scripted-tool-use-replay-not-language-model-agent-evaluation"
        and summary["queries"] == 80
        and summary["estimate_actions"] == 35
        and summary["measure_actions"] == 45
        and summary["allocations_avoided"] == 35
        and summary["final_exact_selections"] == 80
        and summary["invalid_action_executions"] == 0
        and summary["boundary_contract_cases_passed"]
        == summary["boundary_contract_cases"]
        == 9,
        "V8 scripted planner-loop replay changed",
    )
    require(
        len(document["decisions"]) == 80
        and all(row["exact"] for row in document["decisions"]),
        "V8 scripted planner-loop decision inventory changed",
    )


def validate_agentic_interface(root: Path) -> None:
    benchmark = load(root, "agentic-interface-benchmark-v1.json")
    results = load(root, "agentic-interface-results-v1.json")
    require(
        benchmark["schema"] == "scaletether-agentic-interface-benchmark-v1"
        and benchmark["status"] == "frozen-before-language-model-execution"
        and len(benchmark["tasks"]) == 15
        and [task["frozen_action"] for task in benchmark["tasks"]].count("ESTIMATE")
        == 5
        and [task["frozen_action"] for task in benchmark["tasks"]].count("MEASURE") == 5
        and [task["frozen_action"] for task in benchmark["tasks"]].count("UNSUPPORTED")
        == 5,
        "agentic interface benchmark changed",
    )
    summary = results["summary"]
    require(
        results["schema"] == "scaletether-agentic-interface-results-v1"
        and len(results["rows"]) == 45
        and summary["numeric-only"]["protocol_valid"] == 4
        and summary["numeric-only"]["exact_measured_optimum"] == 7
        and summary["numeric-only"]["ignored_measure"] == 5
        and summary["numeric-only"]["ignored_unsupported"] == 5
        and summary["action-only"]["protocol_valid"] == 15
        and summary["action-only"]["exact_measured_optimum"] == 10
        and summary["full"]["protocol_valid"] == 15
        and summary["full"]["exact_measured_optimum"] == 10
        and summary["action-only"]["measurement_calls"]
        == summary["full"]["measurement_calls"]
        == 15,
        "agentic interface result changed",
    )


def validate_agentic_replications(root: Path) -> None:
    replication = load(root, "agentic-interface-replication-v2.json")
    prose = load(root, "agentic-interface-prose-v3.json")
    typed = replication["summary"]
    prose_summary = prose["summary"]
    require(
        replication["schema"] == "scaletether-agentic-interface-replication-v2"
        and len(replication["rows"]) == 360
        and typed["numeric-only"]["protocol_valid"] == 52
        and typed["numeric-only"]["exact_measured_optimum"] == 58
        and typed["numeric-only"]["ignored_measure"] == 38
        and typed["numeric-only"]["unnecessary_measurements"] == 61
        and typed["action-only"]["protocol_valid"] == 120
        and typed["full"]["protocol_valid"] == 120,
        "agentic interface replication changed",
    )
    require(
        prose["schema"] == "scaletether-agentic-interface-prose-v3"
        and len(prose["rows"]) == 120
        and prose_summary["protocol_valid"] == 120
        and prose_summary["exact_measured_optimum"] == 80
        and prose_summary["ignored_measure"] == 0
        and prose_summary["ignored_unsupported"] == 0
        and prose_summary["unnecessary_measurements"] == 0,
        "untyped-prose interface follow-up changed",
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence", type=Path, default=DEFAULT_EVIDENCE)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    provenance = load(args.evidence, "provenance.json")
    require(
        provenance["schema"] == "scaletether-reviewer-artifact-import-v1",
        "provenance schema changed",
    )
    require(
        {
            "planner-interface-study.json",
            "planner-boundary-suite.json",
            "scale-4096-evidence.json",
            "fixed-resource-chronology-v1.json",
            "structural-campaign-identities-v1.json",
            "v8-planner-loop-replay-v1.json",
            "agentic-interface-benchmark-v1.json",
            "agentic-interface-results-v1.json",
        }
        <= set(provenance["members"]),
        "planner or scale evidence is absent from artifact provenance",
    )
    for name, metadata in provenance["members"].items():
        require(
            sha256(args.evidence / name) == metadata["artifact_sha256"],
            f"artifact member hash changed: {name}",
        )
    paired_tp = validate_paired_tp(PAIRED_TP_EVIDENCE)
    validate_measurement_frontier(PAIRED_TP_EVIDENCE)
    v7 = validate_v7(args.evidence)
    tp_a = validate_tp_a_followup(args.evidence)
    multi = validate_16h100(args.evidence)
    one = validate_one_node(args.evidence)
    validate_table(args.evidence, multi, one)
    agent_loop = validate_agent_loop(args.evidence, multi, one)
    validate_planner_interface(args.evidence)
    boundary = validate_planner_boundary(args.evidence)
    validate_scale_4096(args.evidence)
    validate_study_chronology(args.evidence)
    validate_structural_campaign_identities(args.evidence)
    validate_v8_planner_loop(args.evidence)
    validate_agentic_interface(args.evidence)
    validate_agentic_replications(PAIRED_TP_EVIDENCE)
    print(
        "artifact_validation=passed "
        f"paired_tp={paired_tp['contrasts']}/4,"
        f"{paired_tp['outer_observations']}/20 "
        f"paired_tp_worst_percent={paired_tp['worst_error_percent']:.4f} "
        f"v7_median_iteration_percent={v7['median_iteration_ape_percent']:.4f} "
        f"tp_a_followup_ape_percent={tp_a['ape_percent']:.4f} "
        f"invalid_admissions={v7['false_admissions']}/72 "
        f"16h100_retention={multi['retention']:.6f} "
        f"one_node_retention={one['retention']:.6f} "
        f"agent_loop_rows={agent_loop['16h100_acquired_rows']}/"
        f"{agent_loop['16h100_heldout_rows']},"
        f"{agent_loop['one_node_acquired_rows']}/"
        f"{agent_loop['one_node_heldout_rows']} "
        f"planner_boundary={sum(boundary.values())}/9"
    )


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, json.JSONDecodeError) as error:
        raise SystemExit(f"artifact validation failed: {error}") from error

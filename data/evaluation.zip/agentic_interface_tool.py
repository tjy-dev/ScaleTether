#!/usr/bin/env python3
"""Read-only benchmark tool presented to language-model agents."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


CORPUS = (
    Path(__file__).resolve().parent
    / "evidence/scaletether/agentic-interface-benchmark-v1.json"
)


def task(case_id: str) -> dict[str, object]:
    payload = json.loads(CORPUS.read_text())
    try:
        return next(row for row in payload["tasks"] if row["case_id"] == case_id)
    except StopIteration as exc:
        raise SystemExit(f"unknown case: {case_id}") from exc


def query(row: dict[str, object], interface: str) -> dict[str, object]:
    common = {
        "case_id": row["case_id"],
        "workload": {
            "hidden_size": row.get("hidden_size"),
            "sequence_length": row.get("sequence_length"),
            "condition": row.get("query"),
        },
        "candidate_tp": row["candidates"],
    }
    if interface == "numeric-only":
        return common | {"predicted_tp": row["unconditional_tp"]}
    if interface == "action-only":
        return common | {
            "action": row["frozen_action"],
            "selected_tp": row["certified_tp"]
            if row["frozen_action"] == "ESTIMATE"
            else None,
        }
    return common | {
        "action": row["frozen_action"],
        "selected_tp": row["certified_tp"]
        if row["frozen_action"] == "ESTIMATE"
        else None,
        "required_measurements": row["required_measurements"],
        "reason_code": row["reason_code"],
    }


def measure(row: dict[str, object], tp: int) -> dict[str, object]:
    if tp not in row["candidates"]:
        raise SystemExit("TP is not a candidate")
    if row["measured_us"] is None:
        return {
            "case_id": row["case_id"],
            "tp": tp,
            "status": "measurement-unavailable",
        }
    return {
        "case_id": row["case_id"],
        "tp": tp,
        "status": "measured",
        "median_iteration_us": row["measured_us"][str(tp)],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--interface", required=True, choices=["numeric-only", "action-only", "full"]
    )
    parser.add_argument("--case", required=True)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("query")
    measurement = subparsers.add_parser("measure")
    measurement.add_argument("--tp", type=int, required=True)
    args = parser.parse_args()
    row = task(args.case)
    result = (
        query(row, args.interface) if args.command == "query" else measure(row, args.tp)
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
